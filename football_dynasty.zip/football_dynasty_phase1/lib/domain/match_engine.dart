import 'dart:math' as math;
import 'lineup.dart';
import 'models.dart';
import 'rng.dart';

class TeamSheet {
  final Club club;
  final List<LineupSlot> xi;
  final Tactics tactics;
  const TeamSheet(this.club, this.xi, this.tactics);
}

class _Side {
  final TeamSheet sheet;
  final bool isHome;
  double gk = 60, def = 60, mid = 60, att = 60;
  int reds = 0;
  int injuries = 0;
  final Set<String> sentOff = {};
  final Set<String> injuredOff = {};
  final Set<String> yellowed = {};
  int shots = 0, onTarget = 0, yellows = 0, redCount = 0, possessionMinutes = 0;

  _Side(this.sheet, this.isHome) {
    _computeStrength();
  }

  double get mentalityAtt => const [0.97, 1.0, 1.04][sheet.tactics.mentality];
  double get mentalityDef => const [1.04, 1.0, 0.96][sheet.tactics.mentality];
  double get pressMid => const [0.98, 1.0, 1.03][sheet.tactics.pressing];
  double get tempo => const [0.9, 1.0, 1.12][sheet.tactics.tempo];

  void _computeStrength() {
    double avg(PositionGroup g) {
      final list = sheet.xi.where((s) => groupOf(s.slot) == g).toList();
      if (list.isEmpty) return 40;
      return list.fold<double>(0, (a, s) => a + s.effective) / list.length;
    }

    gk = avg(PositionGroup.gk);
    def = avg(PositionGroup.def) * mentalityDef;
    mid = avg(PositionGroup.mid) * pressMid;
    att = avg(PositionGroup.att) * mentalityAtt;
  }

  /// Penalty multiplier for red cards and injuries during the match.
  double get form => math.pow(0.93, reds).toDouble() * math.pow(0.985, injuries).toDouble();

  List<LineupSlot> get onPitch =>
      sheet.xi
          .where((s) => !sentOff.contains(s.player.id) && !injuredOff.contains(s.player.id))
          .toList();
}

class MatchEngine {
  static const _shooterWeight = {
    'ST': 6.0, 'RW': 4.0, 'LW': 4.0, 'AM': 3.5, 'CM': 2.0, 'DM': 1.0,
    'RB': 0.8, 'LB': 0.8, 'CB': 0.6, 'GK': 0.0,
  };

  /// Simulates one match. Output depends only on the inputs and [seed].
  static MatchResult simulate({
    required String fixtureId,
    required TeamSheet home,
    required TeamSheet away,
    required int seed,
  }) {
    final rng = SeededRandom(seed);
    final h = _Side(home, true);
    final a = _Side(away, false);
    final events = <MatchEvent>[];
    final injuries = <String, int>{};
    final yellowPlayers = <String>[];
    final redPlayers = <String>[];
    var homeGoals = 0, awayGoals = 0;
    final extra = rng.range(2, 6);
    final lastMinute = 90 + extra;

    events.add(const MatchEvent(minute: 1, type: EventType.kickoff, detail: 'Kick-off'));

    for (var minute = 1; minute <= lastMinute; minute++) {
      final sides = [h, a];

      // Discipline and injuries.
      for (final s in sides) {
        final pressFoul = const [0.9, 1.0, 1.25][s.sheet.tactics.pressing];
        if (rng.chance(0.0185 * pressFoul)) {
          _yellow(s, rng, minute, events, yellowPlayers, redPlayers);
        }
        if (rng.chance(0.0006)) {
          _sendOff(s, rng, minute, events, redPlayers, 'Straight red card');
        }
        if (rng.chance(0.0005)) {
          _injure(s, rng, minute, events, injuries);
        }
      }

      // Possession and chance creation.
      final homeBoost = 1.04;
      final hm = h.mid * h.form * homeBoost;
      final am = a.mid * a.form;
      final homeHasBall = rng.chance(hm / (hm + am));
      final atk = homeHasBall ? h : a;
      final dfn = homeHasBall ? a : h;
      atk.possessionMinutes++;

      final atkPower = (atk.att * 0.6 + atk.mid * 0.4) * atk.form;
      final dfnPower = (dfn.def * 0.7 + dfn.mid * 0.3) * dfn.form;
      final ratio = atkPower / dfnPower;
      final pChance = 0.205 * atk.tempo * clampD(math.pow(ratio, 1.8).toDouble(), 0.45, 2.2);
      if (!rng.chance(pChance)) continue;

      final onPitch = atk.onPitch;
      if (onPitch.isEmpty) continue;
      final weights = onPitch
          .map((s) => (_shooterWeight[s.slot] ?? 1.0) * math.pow(s.effective / 70, 3).toDouble())
          .toList();
      if (weights.every((w) => w <= 0)) continue;
      final shooter = onPitch[rng.weightedIndex(weights)];
      final shooterRating = shooter.effective;

      atk.shots++;
      final onTargetP = clampD(0.42 + (shooterRating - 65) * 0.004, 0.25, 0.65);
      if (!rng.chance(onTargetP)) {
        events.add(MatchEvent(
          minute: minute,
          type: EventType.shotOff,
          clubId: atk.sheet.club.id,
          playerId: shooter.player.id,
          playerName: shooter.player.name,
          detail: 'shoots wide',
        ));
        continue;
      }
      atk.onTarget++;
      final gkRating = math.max(30.0, dfn.gk);
      final goalP = clampD(
          0.30 * math.pow(shooterRating / gkRating, 1.3) * math.pow(atk.att / dfn.def, 0.4),
          0.10,
          0.55);
      if (rng.chance(goalP)) {
        if (atk.isHome) {
          homeGoals++;
        } else {
          awayGoals++;
        }
        events.add(MatchEvent(
          minute: minute,
          type: EventType.goal,
          clubId: atk.sheet.club.id,
          playerId: shooter.player.id,
          playerName: shooter.player.name,
          detail: 'scores! $homeGoals-$awayGoals',
        ));
      } else {
        final keeper = dfn.onPitch.where((s) => s.slot == 'GK').toList();
        events.add(MatchEvent(
          minute: minute,
          type: EventType.save,
          clubId: dfn.sheet.club.id,
          playerId: keeper.isEmpty ? null : keeper.first.player.id,
          playerName: keeper.isEmpty ? 'Goalkeeper' : keeper.first.player.name,
          detail: 'saves a shot from ${shooter.player.name}',
        ));
      }
    }

    final htGoalsHome = events
        .where((e) => e.type == EventType.goal && e.minute <= 45 && e.clubId == home.club.id)
        .length;
    final htGoalsAway = events
        .where((e) => e.type == EventType.goal && e.minute <= 45 && e.clubId == away.club.id)
        .length;
    events.add(MatchEvent(
        minute: 45, type: EventType.halftime, detail: 'Half-time $htGoalsHome-$htGoalsAway'));
    events.add(MatchEvent(
        minute: lastMinute,
        type: EventType.fulltime,
        detail: 'Full-time $homeGoals-$awayGoals'));
    // Stable chronological order (halftime sorts after minute-45 events).
    final indexed = events.asMap().entries.toList()
      ..sort((x, y) {
        final byMinute = x.value.minute.compareTo(y.value.minute);
        if (byMinute != 0) return byMinute;
        int rank(EventType t) => t == EventType.halftime ? 1 : (t == EventType.kickoff ? -1 : 0);
        final byRank = rank(x.value.type).compareTo(rank(y.value.type));
        return byRank != 0 ? byRank : x.key.compareTo(y.key);
      });
    final ordered = indexed.map((e) => e.value).toList();

    final stats = MatchStats()
      ..homeShots = h.shots
      ..awayShots = a.shots
      ..homeOnTarget = h.onTarget
      ..awayOnTarget = a.onTarget
      ..homeYellows = h.yellows
      ..awayYellows = a.yellows
      ..homeReds = h.redCount
      ..awayReds = a.redCount
      ..homePossession =
          ((h.possessionMinutes / math.max(1, lastMinute)) * 100).round();

    return MatchResult(
      fixtureId: fixtureId,
      homeId: home.club.id,
      awayId: away.club.id,
      seed: seed,
      homeGoals: homeGoals,
      awayGoals: awayGoals,
      events: ordered,
      homeXI: home.xi.map((s) => s.player.id).toList(),
      awayXI: away.xi.map((s) => s.player.id).toList(),
      stats: stats,
      newInjuries: injuries,
      yellowCardPlayers: yellowPlayers,
      redCardPlayers: redPlayers,
    );
  }

  static void _yellow(_Side s, SeededRandom rng, int minute, List<MatchEvent> events,
      List<String> yellowPlayers, List<String> redPlayers) {
    final candidates = s.onPitch.where((x) => x.slot != 'GK').toList();
    if (candidates.isEmpty) return;
    final weights = candidates
        .map((x) => groupOf(x.slot) == PositionGroup.def || x.slot == 'DM' ? 2.0 : 1.0)
        .toList();
    final slot = candidates[rng.weightedIndex(weights)];
    final p = slot.player;
    if (s.yellowed.contains(p.id)) {
      _sendOff(s, rng, minute, events, redPlayers, 'Second yellow card', forced: slot);
      return;
    }
    s.yellowed.add(p.id);
    s.yellows++;
    yellowPlayers.add(p.id);
    events.add(MatchEvent(
      minute: minute,
      type: EventType.yellow,
      clubId: s.sheet.club.id,
      playerId: p.id,
      playerName: p.name,
      detail: 'is shown a yellow card',
    ));
  }

  static void _sendOff(_Side s, SeededRandom rng, int minute, List<MatchEvent> events,
      List<String> redPlayers, String reason, {LineupSlot? forced}) {
    final candidates = s.onPitch.where((x) => x.slot != 'GK').toList();
    if (candidates.isEmpty) return;
    final slot = forced ?? rng.pick(candidates);
    final p = slot.player;
    if (s.sentOff.contains(p.id)) return;
    s.sentOff.add(p.id);
    s.reds++;
    s.redCount++;
    redPlayers.add(p.id);
    events.add(MatchEvent(
      minute: minute,
      type: EventType.red,
      clubId: s.sheet.club.id,
      playerId: p.id,
      playerName: p.name,
      detail: '$reason - sent off',
    ));
  }

  static void _injure(_Side s, SeededRandom rng, int minute, List<MatchEvent> events,
      Map<String, int> injuries) {
    final candidates = s.onPitch.toList();
    if (candidates.isEmpty) return;
    // Tired players are more likely to get hurt.
    final weights = candidates.map((x) => 120.0 - x.player.fitness).toList();
    final slot = candidates[rng.weightedIndex(weights)];
    if (injuries.containsKey(slot.player.id)) return;
    final out = rng.range(1, 3) + (rng.chance(0.15) ? rng.range(3, 8) : 0);
    injuries[slot.player.id] = out;
    s.injuredOff.add(slot.player.id);
    s.injuries++;
    events.add(MatchEvent(
      minute: minute,
      type: EventType.injury,
      clubId: s.sheet.club.id,
      playerId: slot.player.id,
      playerName: slot.player.name,
      detail: 'is injured (out for $out ${out == 1 ? 'match' : 'matches'})',
    ));
  }
}
