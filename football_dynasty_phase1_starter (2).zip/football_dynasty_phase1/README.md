# Football Dynasty — Phase 1 starter

An Android-first, offline-first football management game starter built with Flutter.
The initial app is a navigable UI prototype. It uses clearly labelled demo data; it does
not yet connect to a licensed real-world football data provider or run a full match engine.

## Confirmed product decisions
- Android first
- Flutter + Flame (Flame is reserved for the animated match module)
- Real-world football data through licensed/provider-approved integrations
- Offline-first gameplay, optional online accounts and synchronization

## Requirements
- Flutter SDK (stable channel)
- Android Studio / Android SDK
- Git

## Run
1. Install Flutter and Android Studio.
2. From this directory run:
   ```bash
   flutter create . --platforms=android
   flutter pub get
   flutter run
   ```
3. For the next implementation step, add dependencies:
   ```bash
   flutter pub add sqflite path path_provider connectivity_plus
   flutter pub add flame supabase_flutter
   ```

The starter UI intentionally uses Flutter SDK widgets only so it can be launched before
the database and online adapters are wired in.

## Project structure
```text
lib/
  main.dart
  app.dart
  theme/app_theme.dart
  screens/
    shell_screen.dart
    dashboard_screen.dart
    squad_screen.dart
    transfers_screen.dart
    competitions_screen.dart
    tactics_screen.dart
  data/demo_data.dart
supabase/
  migrations/0001_initial_schema.sql
docs/
  ARCHITECTURE.md
  INTERFACES.md
  DATA_AND_LICENSING.md
```

## Important next steps
1. Generate the Android project with `flutter create .`.
2. Add local SQLite repositories and migrations.
3. Add a licensed football data provider adapter.
4. Add sync queue and Supabase authentication/cloud backup.
5. Build the Flame match scene and deterministic match simulation.
6. Add automated tests before adding more leagues and features.

## Data and licensing
Do not scrape websites or redistribute proprietary player/club datasets, crests, photographs,
kits or competition branding without permission. The SQL schema is designed to store data
from a provider whose terms explicitly permit the intended use. Keep provider attribution,
source IDs, timestamps and licensing metadata with imported records.
