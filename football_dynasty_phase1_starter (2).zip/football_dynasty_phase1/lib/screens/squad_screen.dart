import 'package:flutter/material.dart';
import '../data/demo_data.dart';
import '../theme/app_theme.dart';

class SquadScreen extends StatelessWidget {
  const SquadScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(18), children: [
      const Text('FIRST TEAM', style: TextStyle(color: AppTheme.green, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
      const SizedBox(height: 5),
      const Text('Squad', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800)),
      const SizedBox(height: 6),
      const Text('24 registered players • Demo squad', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 18),
      ...demoPlayers.map((p) => Card(
        child: ListTile(
          leading: CircleAvatar(backgroundColor: AppTheme.panelLight, child: Text(p.position, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold))),
          title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text('${p.position}  •  Age ${p.age}  •  Fitness ${p.fitness}%'),
          trailing: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
            decoration: BoxDecoration(color: AppTheme.green.withValues(alpha: .15), borderRadius: BorderRadius.circular(10)),
            child: Text('${p.rating}', style: const TextStyle(color: AppTheme.green, fontWeight: FontWeight.bold)),
          ),
        ),
      )),
    ]);
  }
}
