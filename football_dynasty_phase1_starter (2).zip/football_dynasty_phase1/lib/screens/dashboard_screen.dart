import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 28),
      children: [
        Row(
          children: [
            const Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('FOOTBALL DYNASTY', style: TextStyle(color: AppTheme.green, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
                SizedBox(height: 5),
                Text('Manager Dashboard', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
              ]),
            ),
            CircleAvatar(
              backgroundColor: AppTheme.panelLight,
              child: Icon(Icons.person, color: AppTheme.green),
            ),
          ],
        ),
        const SizedBox(height: 22),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(colors: [Color(0xFF203B4B), Color(0xFF142638)]),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('YOUR CLUB', style: TextStyle(color: Colors.white70, letterSpacing: 1.1, fontSize: 11)),
            const SizedBox(height: 8),
            const Text('Dynasty Athletic', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const Text('Demo career • Season 2026/27', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 20),
            Row(children: const [
              _Metric(label: 'POSITION', value: '3rd'),
              _Metric(label: 'POINTS', value: '24'),
              _Metric(label: 'BALANCE', value: '€4.5M'),
            ]),
          ]),
        ),
        const SizedBox(height: 22),
        const _SectionTitle('Next fixture', trailing: 'LEAGUE • MATCHDAY 12'),
        const SizedBox(height: 10),
        Card(child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: const [
              _Team(name: 'Dynasty\\nAthletic', initials: 'DA'),
              Text('VS', style: TextStyle(color: Colors.white54, fontWeight: FontWeight.w800)),
              _Team(name: 'Harbour\\nUnited', initials: 'HU'),
            ]),
            const SizedBox(height: 14),
            const Text('Saturday • 15:00 • Dynasty Park', style: TextStyle(color: Colors.white60, fontSize: 12)),
            const SizedBox(height: 14),
            SizedBox(width: double.infinity, child: FilledButton.icon(
              onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Match engine is scheduled for Phase 2/3.')),
              ),
              icon: const Icon(Icons.play_arrow),
              label: const Text('MATCH CENTRE — COMING SOON'),
            )),
          ]),
        )),
        const SizedBox(height: 22),
        const _SectionTitle('Club overview'),
        const SizedBox(height: 10),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.8,
          children: const [
            _OverviewTile(icon: Icons.groups, label: 'First team', value: '24 players'),
            _OverviewTile(icon: Icons.account_balance_wallet, label: 'Wage budget', value: '€185K/wk'),
            _OverviewTile(icon: Icons.trending_up, label: 'Club reputation', value: '68 / 100'),
            _OverviewTile(icon: Icons.stadium, label: 'Stadium', value: '18,500 seats'),
          ],
        ),
        const SizedBox(height: 16),
        const Text('Prototype note: names, figures and fixtures on this screen are fictional demo data.',
          style: TextStyle(color: Colors.white38, fontSize: 11)),
      ],
    );
  }
}

class _Metric extends StatelessWidget {
  final String label, value;
  const _Metric({required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(label, style: const TextStyle(fontSize: 10, color: Colors.white60)),
    const SizedBox(height: 4),
    Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
  ]));
}

class _Team extends StatelessWidget {
  final String name, initials;
  const _Team({required this.name, required this.initials});
  @override
  Widget build(BuildContext context) => Column(children: [
    CircleAvatar(radius: 25, backgroundColor: AppTheme.panelLight, child: Text(initials, style: const TextStyle(fontWeight: FontWeight.bold))),
    const SizedBox(height: 7),
    Text(name, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600)),
  ]);
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final String? trailing;
  const _SectionTitle(this.title, {this.trailing});
  @override
  Widget build(BuildContext context) => Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
    Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    if (trailing != null) Text(trailing!, style: const TextStyle(fontSize: 10, color: Colors.white54)),
  ]);
}

class _OverviewTile extends StatelessWidget {
  final IconData icon;
  final String label, value;
  const _OverviewTile({required this.icon, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Card(child: Padding(
    padding: const EdgeInsets.all(12),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon, color: AppTheme.green, size: 19),
      const SizedBox(height: 7),
      Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
      Text(label, style: const TextStyle(color: Colors.white54, fontSize: 11)),
    ]),
  ));
}
