import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class TransfersScreen extends StatelessWidget {
  const TransfersScreen({super.key});

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('PLAYER MARKET', style: TextStyle(color: AppTheme.green, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
    const SizedBox(height: 5),
    const Text('Transfers', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800)),
    const SizedBox(height: 16),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
      Text('Transfer window', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
      SizedBox(height: 6),
      Text('Summer window • Open', style: TextStyle(color: AppTheme.green)),
      SizedBox(height: 12),
      Text('Available transfer budget', style: TextStyle(color: Colors.white60)),
      Text('€12,000,000', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
    ]))),
    const SizedBox(height: 12),
    const Card(child: ListTile(leading: Icon(Icons.search), title: Text('Scout players'), subtitle: Text('Search by position, age, ability and value'), trailing: Icon(Icons.chevron_right))),
    const Card(child: ListTile(leading: Icon(Icons.description_outlined), title: Text('Offers and negotiations'), subtitle: Text('Review incoming and outgoing bids'), trailing: Icon(Icons.chevron_right))),
    const Card(child: ListTile(leading: Icon(Icons.assignment_ind_outlined), title: Text('Contracts'), subtitle: Text('Renewals, wages and expiry dates'), trailing: Icon(Icons.chevron_right))),
    const SizedBox(height: 12),
    const Text('Transfer actions will be connected to the career database in the next milestone.', style: TextStyle(color: Colors.white38, fontSize: 11)),
  ]);
}
