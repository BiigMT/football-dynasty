import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class TacticsScreen extends StatefulWidget {
  const TacticsScreen({super.key});
  @override
  State<TacticsScreen> createState() => _TacticsScreenState();
}

class _TacticsScreenState extends State<TacticsScreen> {
  String formation = '4-3-3';
  String mentality = 'Balanced';
  String pressing = 'Medium';

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('MATCH PREPARATION', style: TextStyle(color: AppTheme.green, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
    const SizedBox(height: 5),
    const Text('Tactics', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800)),
    const SizedBox(height: 16),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Formation', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      DropdownButtonFormField<String>(
        value: formation,
        decoration: const InputDecoration(border: OutlineInputBorder()),
        items: ['4-3-3', '4-2-3-1', '4-4-2', '3-5-2'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
        onChanged: (v) => setState(() => formation = v ?? formation),
      ),
      const SizedBox(height: 16),
      const Text('Mentality', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      SegmentedButton<String>(
        segments: const [
          ButtonSegment(value: 'Defensive', label: Text('Defend')),
          ButtonSegment(value: 'Balanced', label: Text('Balanced')),
          ButtonSegment(value: 'Attacking', label: Text('Attack')),
        ],
        selected: {mentality},
        onSelectionChanged: (v) => setState(() => mentality = v.first),
      ),
      const SizedBox(height: 16),
      const Text('Pressing intensity', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      DropdownButtonFormField<String>(
        value: pressing,
        decoration: const InputDecoration(border: OutlineInputBorder()),
        items: ['Low', 'Medium', 'High'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
        onChanged: (v) => setState(() => pressing = v ?? pressing),
      ),
    ]))),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Current tactical setup', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text('$formation  •  $mentality  •  $pressing pressing', style: const TextStyle(color: AppTheme.green)),
      const SizedBox(height: 6),
      const Text('Tactical settings are currently local UI state. Persistence and match-engine effects are next milestones.', style: TextStyle(color: Colors.white54, fontSize: 11)),
    ]))),
  ]);
}
