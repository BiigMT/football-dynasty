import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class CompetitionsScreen extends StatelessWidget {
  const CompetitionsScreen({super.key});

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('FOOTBALL WORLD', style: TextStyle(color: AppTheme.green, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
    const SizedBox(height: 5),
    const Text('Competitions', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800)),
    const SizedBox(height: 16),
    const Text('GLOBAL COMPETITIONS', style: TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    const _Competition(name: 'Premier Division', region: 'England • Demo competition', position: '3rd'),
    const _Competition(name: 'Continental Champions Cup', region: 'International • Demo competition', position: 'Group stage'),
    const _Competition(name: 'National Cup', region: 'Domestic • Demo competition', position: 'Quarter-final'),
    const SizedBox(height: 14),
    const Text('League table and fixture data will be populated from the career database.', style: TextStyle(color: Colors.white38, fontSize: 11)),
  ]);
}

class _Competition extends StatelessWidget {
  final String name, region, position;
  const _Competition({required this.name, required this.region, required this.position});
  @override
  Widget build(BuildContext context) => Card(child: ListTile(
    leading: const CircleAvatar(backgroundColor: AppTheme.panelLight, child: Icon(Icons.emoji_events_outlined, color: AppTheme.gold)),
    title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
    subtitle: Text(region),
    trailing: Text(position, style: const TextStyle(color: AppTheme.green, fontWeight: FontWeight.bold, fontSize: 11)),
  ));
}
