import 'package:flutter/material.dart';
import 'screens/shell_screen.dart';
import 'theme/app_theme.dart';

class FootballDynastyApp extends StatelessWidget {
  const FootballDynastyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Football Dynasty',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark(),
      home: const ShellScreen(),
    );
  }
}
