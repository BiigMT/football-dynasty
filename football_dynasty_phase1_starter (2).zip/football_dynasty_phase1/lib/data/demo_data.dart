class DemoPlayer {
  final String name;
  final String position;
  final int age;
  final int rating;
  final int fitness;

  const DemoPlayer(this.name, this.position, this.age, this.rating, this.fitness);
}

// Fictional placeholder records only. Replace with licensed provider data later.
const demoPlayers = <DemoPlayer>[
  DemoPlayer('Daniel Mwansa', 'GK', 24, 76, 94),
  DemoPlayer('Alex Morganfield', 'RB', 22, 72, 91),
  DemoPlayer('Joseph Banda', 'CB', 27, 78, 88),
  DemoPlayer('Samuel Okoro', 'CB', 25, 75, 93),
  DemoPlayer('Luca Bennett', 'LB', 21, 73, 90),
  DemoPlayer('Peter Chileshe', 'DM', 26, 79, 86),
  DemoPlayer('Noah Williams', 'CM', 23, 81, 95),
  DemoPlayer('Mateo Silva', 'AM', 24, 83, 89),
  DemoPlayer('Brian Phiri', 'RW', 20, 77, 97),
  DemoPlayer('David Kamara', 'ST', 25, 84, 92),
  DemoPlayer('Ethan Clarke', 'LW', 22, 78, 90),
];
