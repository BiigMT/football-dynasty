import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

String fmtMoney(int v) {
  final sign = v < 0 ? '-' : '';
  final a = v.abs();
  if (a >= 1000000) return '$sign€${(a / 1000000).toStringAsFixed(1)}M';
  if (a >= 1000) return '$sign€${(a / 1000).round()}K';
  return '$sign€$a';
}

String fmtWage(int v) => '${fmtMoney(v)}/wk';

Color ratingColor(int r) {
  if (r >= 80) return AppTheme.green;
  if (r >= 70) return const Color(0xFFB8E986);
  if (r >= 60) return AppTheme.gold;
  return Colors.orangeAccent;
}

class ScreenHeader extends StatelessWidget {
  final String kicker;
  final String title;
  final Widget? trailing;
  const ScreenHeader({super.key, required this.kicker, required this.title, this.trailing});

  @override
  Widget build(BuildContext context) => Row(children: [
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(kicker,
                style: const TextStyle(
                    color: AppTheme.green, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
            const SizedBox(height: 5),
            Text(title, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w800)),
          ]),
        ),
        if (trailing != null) trailing!,
      ]);
}

class RatingBadge extends StatelessWidget {
  final int rating;
  const RatingBadge(this.rating, {super.key});

  @override
  Widget build(BuildContext context) {
    final c = ratingColor(rating);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
          color: c.withValues(alpha: .15), borderRadius: BorderRadius.circular(10)),
      child: Text('$rating', style: TextStyle(color: c, fontWeight: FontWeight.bold)),
    );
  }
}

class SectionLabel extends StatelessWidget {
  final String text;
  const SectionLabel(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 8),
        child: Text(text,
            style: const TextStyle(
                color: Colors.white54, fontSize: 11, fontWeight: FontWeight.bold)),
      );
}

class ClubCrest extends StatelessWidget {
  final String shortName;
  final int colorValue;
  final double radius;
  const ClubCrest(this.shortName, this.colorValue, {super.key, this.radius = 22});

  @override
  Widget build(BuildContext context) => CircleAvatar(
        radius: radius,
        backgroundColor: Color(colorValue),
        child: Text(shortName,
            style: TextStyle(
                fontSize: radius * 0.5, fontWeight: FontWeight.w800, color: Colors.white)),
      );
}

Future<bool> confirm(BuildContext context, String title, String body,
    {String action = 'Confirm'}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(body),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(action)),
      ],
    ),
  );
  return r ?? false;
}

void toast(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));
}
