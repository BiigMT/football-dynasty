import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../domain/career.dart';

class SaveSummary {
  final int slot;
  final String managerName;
  final String clubName;
  final String seasonLabel;
  final int matchday;
  const SaveSummary(this.slot, this.managerName, this.clubName, this.seasonLabel, this.matchday);
}

abstract class SaveStore {
  static const slotCount = 3;
  Future<Career?> load(int slot);
  Future<void> save(int slot, Career career);
  Future<void> delete(int slot);
  Future<List<SaveSummary?>> summaries();
}

SaveSummary summaryOf(int slot, Career c) =>
    SaveSummary(slot, c.managerName, c.userClub.name, c.seasonLabel, c.matchday);

/// Stores each slot as a JSON file in the app's documents directory.
/// Writes go to a temp file first and are then renamed, so a crash mid-save
/// cannot corrupt the previous save.
class FileSaveStore implements SaveStore {
  Directory? _dir;

  Future<File> _file(int slot, {bool temp = false}) async {
    _dir ??= await getApplicationDocumentsDirectory();
    return File('${_dir!.path}/career_slot_$slot.json${temp ? '.tmp' : ''}');
  }

  @override
  Future<Career?> load(int slot) async {
    final f = await _file(slot);
    if (!await f.exists()) return null;
    try {
      final data = jsonDecode(await f.readAsString()) as Map<String, dynamic>;
      return Career.fromJson(data);
    } catch (_) {
      return null; // unreadable or newer-version save
    }
  }

  @override
  Future<void> save(int slot, Career career) async {
    final tmp = await _file(slot, temp: true);
    await tmp.writeAsString(jsonEncode(career.toJson()), flush: true);
    await tmp.rename((await _file(slot)).path);
  }

  @override
  Future<void> delete(int slot) async {
    final f = await _file(slot);
    if (await f.exists()) await f.delete();
  }

  @override
  Future<List<SaveSummary?>> summaries() async {
    final out = <SaveSummary?>[];
    for (var i = 1; i <= SaveStore.slotCount; i++) {
      final c = await load(i);
      out.add(c == null ? null : summaryOf(i, c));
    }
    return out;
  }
}

/// In-memory store for tests.
class MemorySaveStore implements SaveStore {
  final Map<int, String> _data = {};

  @override
  Future<Career?> load(int slot) async {
    final raw = _data[slot];
    return raw == null ? null : Career.fromJson(jsonDecode(raw) as Map<String, dynamic>);
  }

  @override
  Future<void> save(int slot, Career career) async =>
      _data[slot] = jsonEncode(career.toJson());

  @override
  Future<void> delete(int slot) async => _data.remove(slot);

  @override
  Future<List<SaveSummary?>> summaries() async {
    final out = <SaveSummary?>[];
    for (var i = 1; i <= SaveStore.slotCount; i++) {
      final c = await load(i);
      out.add(c == null ? null : summaryOf(i, c));
    }
    return out;
  }
}
