import 'package:flutter/material.dart';
import 'data/save_store.dart';
import 'screens/shell_screen.dart';
import 'screens/start_screen.dart';
import 'state/game_controller.dart';
import 'theme/app_theme.dart';

class FootballDynastyApp extends StatefulWidget {
  final SaveStore? store;
  const FootballDynastyApp({super.key, this.store});

  @override
  State<FootballDynastyApp> createState() => _FootballDynastyAppState();
}

class _FootballDynastyAppState extends State<FootballDynastyApp> {
  late final GameController controller;

  @override
  void initState() {
    super.initState();
    controller = GameController(widget.store ?? FileSaveStore())..init();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => GameScope(
        controller: controller,
        child: MaterialApp(
          title: 'Football Dynasty',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.dark(),
          home: const _Root(),
        ),
      );
}

class _Root extends StatelessWidget {
  const _Root();

  @override
  Widget build(BuildContext context) {
    final game = GameScope.of(context);
    if (game.loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return game.career == null ? const StartScreen() : const ShellScreen();
  }
}
