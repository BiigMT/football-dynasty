import 'dart:math' as math;

/// Deterministic PRNG (mulberry32). Implemented by hand so that a stored seed
/// reproduces exactly the same match on every device and Dart version.
class SeededRandom {
  int _state;
  SeededRandom(int seed) : _state = seed & 0xFFFFFFFF;

  static int _imul(int a, int b) => (a * b) & 0xFFFFFFFF;

  double nextDouble() {
    _state = (_state + 0x6D2B79F5) & 0xFFFFFFFF;
    var t = _state;
    t = _imul(t ^ (t >>> 15), t | 1);
    t = (t ^ ((t + _imul(t ^ (t >>> 7), t | 61)) & 0xFFFFFFFF)) & 0xFFFFFFFF;
    return ((t ^ (t >>> 14)) & 0xFFFFFFFF) / 4294967296.0;
  }

  /// Integer in [0, max).
  int nextInt(int max) => (nextDouble() * max).floor();

  /// Integer in [min, max] inclusive.
  int range(int min, int max) => min + nextInt(max - min + 1);

  bool chance(double p) => nextDouble() < p;

  T pick<T>(List<T> items) => items[nextInt(items.length)];

  /// Approximately normal, mean 0, standard deviation 1.
  double gaussian() => (nextDouble() + nextDouble() + nextDouble() - 1.5) * 2;

  /// Weighted index selection. Weights must not all be zero.
  int weightedIndex(List<double> weights) {
    final total = weights.fold<double>(0, (a, b) => a + b);
    var roll = nextDouble() * total;
    for (var i = 0; i < weights.length; i++) {
      roll -= weights[i];
      if (roll < 0) return i;
    }
    return weights.length - 1;
  }

  void shuffle<T>(List<T> list) {
    for (var i = list.length - 1; i > 0; i--) {
      final j = nextInt(i + 1);
      final tmp = list[i];
      list[i] = list[j];
      list[j] = tmp;
    }
  }
}

/// Combines two integers into a well-mixed 32-bit seed.
int mixSeed(int a, int b) {
  var h = (a ^ (b * 0x9E3779B1)) & 0xFFFFFFFF;
  h = ((h ^ (h >>> 16)) * 0x85EBCA6B) & 0xFFFFFFFF;
  h = ((h ^ (h >>> 13)) * 0xC2B2AE35) & 0xFFFFFFFF;
  return (h ^ (h >>> 16)) & 0xFFFFFFFF;
}

int hashString(String s) {
  var h = 2166136261;
  for (final c in s.codeUnits) {
    h = ((h ^ c) * 16777619) & 0xFFFFFFFF;
  }
  return h;
}

double clampD(double v, double lo, double hi) => math.min(hi, math.max(lo, v));
