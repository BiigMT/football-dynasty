import 'economy.dart';

const allPositions = ['GK', 'RB', 'CB', 'LB', 'DM', 'CM', 'AM', 'RW', 'LW', 'ST'];

enum PositionGroup { gk, def, mid, att }

PositionGroup groupOf(String pos) {
  switch (pos) {
    case 'GK':
      return PositionGroup.gk;
    case 'RB':
    case 'CB':
    case 'LB':
      return PositionGroup.def;
    case 'DM':
    case 'CM':
    case 'AM':
      return PositionGroup.mid;
    default:
      return PositionGroup.att;
  }
}

/// Slot positions (11 per formation, GK first).
const formations = <String, List<String>>{
  '4-3-3': ['GK', 'RB', 'CB', 'CB', 'LB', 'DM', 'CM', 'CM', 'RW', 'ST', 'LW'],
  '4-2-3-1': ['GK', 'RB', 'CB', 'CB', 'LB', 'DM', 'DM', 'RW', 'AM', 'LW', 'ST'],
  '4-4-2': ['GK', 'RB', 'CB', 'CB', 'LB', 'RW', 'CM', 'CM', 'LW', 'ST', 'ST'],
  '3-5-2': ['GK', 'CB', 'CB', 'CB', 'RB', 'CM', 'DM', 'CM', 'LB', 'ST', 'ST'],
};

const mentalityLabels = ['Defensive', 'Balanced', 'Attacking'];
const pressingLabels = ['Low', 'Medium', 'High'];
const tempoLabels = ['Slow', 'Normal', 'Fast'];

class Player {
  final String id;
  String name;
  String position;
  int age;
  int rating;
  int potential;
  int fitness;
  int morale;
  int wage; // weekly, in euros
  int contractYears;
  String? clubId; // null = free agent
  int injuredMatches;
  int suspendedMatches;
  int yellowCards;
  int appearances;
  int goals;

  Player({
    required this.id,
    required this.name,
    required this.position,
    required this.age,
    required this.rating,
    required this.potential,
    this.fitness = 100,
    this.morale = 65,
    required this.wage,
    required this.contractYears,
    this.clubId,
    this.injuredMatches = 0,
    this.suspendedMatches = 0,
    this.yellowCards = 0,
    this.appearances = 0,
    this.goals = 0,
  });

  PositionGroup get group => groupOf(position);
  bool get isAvailable => injuredMatches == 0 && suspendedMatches == 0;
  int get value => Economy.value(this);

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'pos': position,
        'age': age,
        'ovr': rating,
        'pot': potential,
        'fit': fitness,
        'mor': morale,
        'wage': wage,
        'ctr': contractYears,
        'club': clubId,
        'inj': injuredMatches,
        'sus': suspendedMatches,
        'yel': yellowCards,
        'app': appearances,
        'gls': goals,
      };

  factory Player.fromJson(Map<String, dynamic> j) => Player(
        id: j['id'] as String,
        name: j['name'] as String,
        position: j['pos'] as String,
        age: j['age'] as int,
        rating: j['ovr'] as int,
        potential: j['pot'] as int,
        fitness: j['fit'] as int,
        morale: j['mor'] as int,
        wage: j['wage'] as int,
        contractYears: j['ctr'] as int,
        clubId: j['club'] as String?,
        injuredMatches: j['inj'] as int,
        suspendedMatches: j['sus'] as int,
        yellowCards: j['yel'] as int,
        appearances: j['app'] as int,
        goals: j['gls'] as int,
      );
}

class Tactics {
  String formation;
  int mentality; // 0..2
  int pressing; // 0..2
  int tempo; // 0..2
  /// Player id per formation slot; empty string = choose automatically.
  List<String> lineup;

  Tactics({
    this.formation = '4-3-3',
    this.mentality = 1,
    this.pressing = 1,
    this.tempo = 1,
    List<String>? lineup,
  }) : lineup = lineup ?? List<String>.filled(11, '');

  Tactics copy() => Tactics(
        formation: formation,
        mentality: mentality,
        pressing: pressing,
        tempo: tempo,
        lineup: List<String>.from(lineup),
      );

  Map<String, dynamic> toJson() => {
        'f': formation,
        'm': mentality,
        'p': pressing,
        't': tempo,
        'l': lineup,
      };

  factory Tactics.fromJson(Map<String, dynamic> j) => Tactics(
        formation: j['f'] as String,
        mentality: j['m'] as int,
        pressing: j['p'] as int,
        tempo: j['t'] as int,
        lineup: (j['l'] as List).cast<String>(),
      );
}

class Club {
  final String id;
  String name;
  String shortName;
  int reputation; // 1..100
  int balance;
  int transferBudget;
  int wageBudget; // weekly
  int stadiumCapacity;
  int colorValue;
  Tactics tactics;

  Club({
    required this.id,
    required this.name,
    required this.shortName,
    required this.reputation,
    required this.balance,
    required this.transferBudget,
    required this.wageBudget,
    required this.stadiumCapacity,
    required this.colorValue,
    Tactics? tactics,
  }) : tactics = tactics ?? Tactics();

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'short': shortName,
        'rep': reputation,
        'bal': balance,
        'tb': transferBudget,
        'wb': wageBudget,
        'cap': stadiumCapacity,
        'col': colorValue,
        'tac': tactics.toJson(),
      };

  factory Club.fromJson(Map<String, dynamic> j) => Club(
        id: j['id'] as String,
        name: j['name'] as String,
        shortName: j['short'] as String,
        reputation: j['rep'] as int,
        balance: j['bal'] as int,
        transferBudget: j['tb'] as int,
        wageBudget: j['wb'] as int,
        stadiumCapacity: j['cap'] as int,
        colorValue: j['col'] as int,
        tactics: Tactics.fromJson(j['tac'] as Map<String, dynamic>),
      );
}

class GoalRecord {
  final String playerId;
  final String clubId;
  final int minute;
  const GoalRecord(this.playerId, this.clubId, this.minute);

  Map<String, dynamic> toJson() => {'p': playerId, 'c': clubId, 'm': minute};
  factory GoalRecord.fromJson(Map<String, dynamic> j) =>
      GoalRecord(j['p'] as String, j['c'] as String, j['m'] as int);
}

class Fixture {
  final String id;
  final int season;
  final int matchday;
  final String homeId;
  final String awayId;
  int? homeGoals;
  int? awayGoals;
  List<GoalRecord> scorers;

  Fixture({
    required this.id,
    required this.season,
    required this.matchday,
    required this.homeId,
    required this.awayId,
    this.homeGoals,
    this.awayGoals,
    List<GoalRecord>? scorers,
  }) : scorers = scorers ?? [];

  bool get played => homeGoals != null && awayGoals != null;
  bool involves(String clubId) => homeId == clubId || awayId == clubId;

  Map<String, dynamic> toJson() => {
        'id': id,
        's': season,
        'md': matchday,
        'h': homeId,
        'a': awayId,
        'hg': homeGoals,
        'ag': awayGoals,
        'sc': scorers.map((g) => g.toJson()).toList(),
      };

  factory Fixture.fromJson(Map<String, dynamic> j) => Fixture(
        id: j['id'] as String,
        season: j['s'] as int,
        matchday: j['md'] as int,
        homeId: j['h'] as String,
        awayId: j['a'] as String,
        homeGoals: j['hg'] as int?,
        awayGoals: j['ag'] as int?,
        scorers: (j['sc'] as List)
            .map((e) => GoalRecord.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}

enum EventType { kickoff, shotOff, save, goal, yellow, red, injury, halftime, fulltime }

class MatchEvent {
  final int minute;
  final EventType type;
  final String? clubId;
  final String? playerId;
  final String? playerName;
  final String detail;

  const MatchEvent({
    required this.minute,
    required this.type,
    this.clubId,
    this.playerId,
    this.playerName,
    this.detail = '',
  });

  String get minuteLabel => minute > 90 ? '90+${minute - 90}\'' : '$minute\'';

  Map<String, dynamic> toJson() => {
        'm': minute,
        't': type.index,
        'c': clubId,
        'p': playerId,
        'n': playerName,
        'd': detail,
      };

  factory MatchEvent.fromJson(Map<String, dynamic> j) => MatchEvent(
        minute: j['m'] as int,
        type: EventType.values[j['t'] as int],
        clubId: j['c'] as String?,
        playerId: j['p'] as String?,
        playerName: j['n'] as String?,
        detail: j['d'] as String,
      );
}

class MatchStats {
  MatchStats();
  int homeShots = 0, awayShots = 0;
  int homeOnTarget = 0, awayOnTarget = 0;
  int homeYellows = 0, awayYellows = 0;
  int homeReds = 0, awayReds = 0;
  int homePossession = 50;

  Map<String, dynamic> toJson() => {
        'hs': homeShots,
        'as': awayShots,
        'ho': homeOnTarget,
        'ao': awayOnTarget,
        'hy': homeYellows,
        'ay': awayYellows,
        'hr': homeReds,
        'ar': awayReds,
        'hp': homePossession,
      };

  factory MatchStats.fromJson(Map<String, dynamic> j) => MatchStats()
    ..homeShots = j['hs'] as int
    ..awayShots = j['as'] as int
    ..homeOnTarget = j['ho'] as int
    ..awayOnTarget = j['ao'] as int
    ..homeYellows = j['hy'] as int
    ..awayYellows = j['ay'] as int
    ..homeReds = j['hr'] as int
    ..awayReds = j['ar'] as int
    ..homePossession = j['hp'] as int;
}

class MatchResult {
  final String fixtureId;
  final String homeId;
  final String awayId;
  final int seed;
  final int homeGoals;
  final int awayGoals;
  final List<MatchEvent> events;
  final List<String> homeXI;
  final List<String> awayXI;
  final MatchStats stats;
  final Map<String, int> newInjuries; // playerId -> matches out
  final List<String> yellowCardPlayers;
  final List<String> redCardPlayers;

  MatchResult({
    required this.fixtureId,
    required this.homeId,
    required this.awayId,
    required this.seed,
    required this.homeGoals,
    required this.awayGoals,
    required this.events,
    required this.homeXI,
    required this.awayXI,
    required this.stats,
    required this.newInjuries,
    required this.yellowCardPlayers,
    required this.redCardPlayers,
  });

  Map<String, dynamic> toJson() => {
        'fx': fixtureId,
        'h': homeId,
        'a': awayId,
        'seed': seed,
        'hg': homeGoals,
        'ag': awayGoals,
        'ev': events.map((e) => e.toJson()).toList(),
        'hxi': homeXI,
        'axi': awayXI,
        'st': stats.toJson(),
        'inj': newInjuries,
        'yc': yellowCardPlayers,
        'rc': redCardPlayers,
      };

  factory MatchResult.fromJson(Map<String, dynamic> j) => MatchResult(
        fixtureId: j['fx'] as String,
        homeId: j['h'] as String,
        awayId: j['a'] as String,
        seed: j['seed'] as int,
        homeGoals: j['hg'] as int,
        awayGoals: j['ag'] as int,
        events: (j['ev'] as List)
            .map((e) => MatchEvent.fromJson(e as Map<String, dynamic>))
            .toList(),
        homeXI: (j['hxi'] as List).cast<String>(),
        awayXI: (j['axi'] as List).cast<String>(),
        stats: MatchStats.fromJson(j['st'] as Map<String, dynamic>),
        newInjuries: (j['inj'] as Map).map((k, v) => MapEntry(k as String, v as int)),
        yellowCardPlayers: (j['yc'] as List).cast<String>(),
        redCardPlayers: (j['rc'] as List).cast<String>(),
      );
}

class TransferOffer {
  final String id;
  final String playerId;
  final String fromClubId;
  final int fee;
  final int expiresMatchday;
  final int season;

  const TransferOffer({
    required this.id,
    required this.playerId,
    required this.fromClubId,
    required this.fee,
    required this.expiresMatchday,
    required this.season,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'p': playerId,
        'c': fromClubId,
        'fee': fee,
        'exp': expiresMatchday,
        's': season,
      };

  factory TransferOffer.fromJson(Map<String, dynamic> j) => TransferOffer(
        id: j['id'] as String,
        playerId: j['p'] as String,
        fromClubId: j['c'] as String,
        fee: j['fee'] as int,
        expiresMatchday: j['exp'] as int,
        season: j['s'] as int,
      );
}

class NewsItem {
  final int season;
  final int matchday;
  final String text;
  const NewsItem(this.season, this.matchday, this.text);

  Map<String, dynamic> toJson() => {'s': season, 'md': matchday, 't': text};
  factory NewsItem.fromJson(Map<String, dynamic> j) =>
      NewsItem(j['s'] as int, j['md'] as int, j['t'] as String);
}

class SeasonRecord {
  final int season;
  final String championId;
  final int userPosition;
  final int userPoints;
  final int objective;
  const SeasonRecord({
    required this.season,
    required this.championId,
    required this.userPosition,
    required this.userPoints,
    required this.objective,
  });

  Map<String, dynamic> toJson() => {
        's': season,
        'ch': championId,
        'pos': userPosition,
        'pts': userPoints,
        'obj': objective,
      };

  factory SeasonRecord.fromJson(Map<String, dynamic> j) => SeasonRecord(
        season: j['s'] as int,
        championId: j['ch'] as String,
        userPosition: j['pos'] as int,
        userPoints: j['pts'] as int,
        objective: j['obj'] as int,
      );
}

class ActionResult {
  final bool ok;
  final String message;
  const ActionResult(this.ok, this.message);
}
