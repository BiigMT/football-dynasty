import 'dart:math' as math;
import 'economy.dart';
import 'models.dart';
import 'rng.dart';

/// Generates a fully fictional football world. Names, clubs and ratings are
/// invented; nothing here is derived from real-world data. A licensed data
/// provider can replace this through `FootballDataProvider`.
class WorldGenerator {
  static const _clubSeeds = <List<Object>>[
    ['Dynasty Athletic', 'DYA', 68, 0xFF2E7D32],
    ['Harbour United', 'HBU', 72, 0xFF1565C0],
    ['Northgate Rovers', 'NGR', 63, 0xFFC62828],
    ['Redwood City', 'RWC', 78, 0xFFB71C1C],
    ['Ironbridge Town', 'IBT', 55, 0xFF455A64],
    ['Kingsmead FC', 'KMD', 66, 0xFF6A1B9A],
    ['Valley Wanderers', 'VLW', 52, 0xFF00838F],
    ['Stonebridge Albion', 'SBA', 60, 0xFF283593],
    ['Eastfield Rangers', 'EFR', 58, 0xFFEF6C00],
    ['Westhaven Athletic', 'WHA', 70, 0xFF00695C],
    ['Silverlake FC', 'SLK', 74, 0xFF78909C],
    ['Brookside United', 'BKU', 50, 0xFF558B2F],
    ['Crownhill City', 'CHC', 76, 0xFFFFA000],
    ['Oakmoor Town', 'OKM', 48, 0xFF5D4037],
    ['Lakeshore Rovers', 'LKR', 61, 0xFF0277BD],
    ['Falconridge Albion', 'FRA', 65, 0xFFAD1457],
  ];

  static const _first = [
    'Daniel', 'Alex', 'Joseph', 'Samuel', 'Luca', 'Peter', 'Noah', 'Mateo', 'Brian',
    'David', 'Ethan', 'Marcus', 'Liam', 'Oscar', 'Felix', 'Hugo', 'Ivan', 'Jonas',
    'Kofi', 'Leon', 'Mason', 'Nico', 'Omar', 'Pablo', 'Rafael', 'Sven', 'Tomas',
    'Victor', 'Yusuf', 'Zane', 'Adrian', 'Bruno', 'Callum', 'Dario', 'Elias',
    'Fabian', 'Gabriel', 'Henrik', 'Isaac', 'Jamal', 'Kian', 'Lars', 'Miguel',
    'Nathan', 'Owen', 'Patrick', 'Quinn', 'Rory', 'Stefan', 'Theo',
  ];

  static const _last = [
    'Mwansa', 'Morganfield', 'Banda', 'Okoro', 'Bennett', 'Chileshe', 'Williams',
    'Silva', 'Phiri', 'Kamara', 'Clarke', 'Novak', 'Hartmann', 'Ibrahim', 'Jensen',
    'Keller', 'Lindqvist', 'Moreau', 'Nakamura', 'Ortega', 'Petrov', 'Quintero',
    'Rossi', 'Santos', 'Torres', 'Underwood', 'Vasquez', 'Walker', 'Xavier',
    'Yilmaz', 'Zielinski', 'Abara', 'Brandt', 'Castillo', 'Dubois', 'Eriksen',
    'Fontaine', 'Grayson', 'Holloway', 'Ismail', 'Jovanovic', 'Kowalski', 'Larsen',
    'Mendes', 'Nash', 'Okafor', 'Prescott', 'Rahman', 'Sutherland', 'Thorne',
  ];

  /// 24-player squad template.
  static const squadTemplate = <String, int>{
  'GK': 3, 'RB': 2, 'CB': 4, 'LB': 2, 'DM': 2, 'CM': 2,
  'AM': 2, 'RW': 2, 'LW': 2, 'ST': 3,
};
  static String playerId(int n) => 'p${n.toString().padLeft(5, '0')}';

  static Player generatePlayer({
    required SeededRandom rng,
    required int number,
    required String position,
    required int level,
    String? clubId,
    int? fixedAge,
  }) {
    final age = fixedAge ?? _age(rng);
    final rating = math.max(35, math.min(90, (level + rng.gaussian() * 5).round()));
    int potential;
    if (age <= 21) {
      potential = rating + rng.range(4, 16);
    } else if (age <= 24) {
      potential = rating + rng.range(1, 9);
    } else {
      potential = rating + rng.range(0, 2);
    }
    potential = math.min(95, potential);
    final p = Player(
      id: playerId(number),
      name: '${rng.pick(_first)} ${rng.pick(_last)}',
      position: position,
      age: age,
      rating: rating,
      potential: potential,
      fitness: rng.range(90, 100),
      morale: 65,
      wage: 0,
      contractYears: rng.range(1, 5),
      clubId: clubId,
    );
    p.wage = Economy.wageFor(p);
    return p;
  }

  static int _age(SeededRandom rng) {
    // Triangular-ish distribution centred on mid-20s.
    final a = rng.range(18, 34);
    final b = rng.range(19, 31);
    return (a + b) ~/ 2;
  }

  static Club generateClubShell(int index, SeededRandom rng) {
    final s = _clubSeeds[index];
    final rep = s[2] as int;
    return Club(
      id: 'c${(index + 1).toString().padLeft(2, '0')}',
      name: s[0] as String,
      shortName: s[1] as String,
      reputation: rep,
      balance: rep * 66000,
      transferBudget: rep * 176000,
      wageBudget: 0,
      stadiumCapacity: 8000 + (rep - 40) * 450,
      colorValue: s[3] as int,
      tactics: Tactics(
        formation: formations.keys.elementAt(rng.nextInt(formations.length)),
      ),
    );
  }

  static int get clubCount => _clubSeeds.length;

  /// Creates clubs and players. Returns the next free player number.
  static int generate({
    required int seed,
    required Map<String, Club> clubs,
    required Map<String, Player> players,
  }) {
    final rng = SeededRandom(mixSeed(seed, 77));
    var number = 1;
    for (var i = 0; i < clubCount; i++) {
      final club = generateClubShell(i, rng);
      clubs[club.id] = club;
      var bill = 0;
      squadTemplate.forEach((pos, count) {
        for (var k = 0; k < count; k++) {
          // Starters of each position are stronger than backups.
          final level = club.reputation - 4 - (k * 3);
          final p = generatePlayer(
            rng: rng,
            number: number++,
            position: pos,
            level: level,
            clubId: club.id,
          );
          players[p.id] = p;
          bill += p.wage;
        }
      });
      club.wageBudget = (bill * 1.12 / 1000).round() * 1000;
    }
    // Initial free-agent pool.
    number = generateFreeAgents(rng: rng, players: players, startNumber: number, count: 30);
    return number;
  }

  static int generateFreeAgents({
    required SeededRandom rng,
    required Map<String, Player> players,
    required int startNumber,
    required int count,
  }) {
    var number = startNumber;
    for (var i = 0; i < count; i++) {
      final pos = rng.pick(allPositions);
      final p = generatePlayer(
        rng: rng,
        number: number++,
        position: pos,
        level: rng.range(48, 66),
        fixedAge: rng.range(21, 34),
      );
      p.contractYears = 0;
      players[p.id] = p;
    }
    return number;
  }

  /// Youth intake used to refill AI squads after retirements.
  static Player generateYouth(SeededRandom rng, int number, String position, String clubId) {
    final p = generatePlayer(
      rng: rng,
      number: number,
      position: position,
      level: rng.range(42, 56),
      clubId: clubId,
      fixedAge: rng.range(17, 19),
    );
    p.contractYears = rng.range(2, 4);
    return p;
  }
}
