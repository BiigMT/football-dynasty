import 'rng.dart';
import 'models.dart';

class Progression {
  static int _clamp(int v, int lo, int hi) => v < lo ? lo : (v > hi ? hi : v);

  /// Ages the player by one year and adjusts ability for the new season.
  static void ageOneYear(Player p, SeededRandom rng) {
    p.age++;
    final gap = p.potential - p.rating;
    int delta;
    if (p.age <= 21) {
      delta = (gap * (0.30 + 0.25 * rng.nextDouble())).round();
    } else if (p.age <= 25) {
      delta = (gap * (0.20 + 0.20 * rng.nextDouble())).round() + (rng.chance(0.2) ? -1 : 0);
    } else if (p.age <= 29) {
      delta = rng.range(-1, 1);
    } else if (p.age <= 32) {
      delta = -rng.range(0, 2);
    } else {
      delta = -rng.range(1, 3);
    }
    p.rating = _clamp(p.rating + delta, 30, 95);
    if (p.age >= 26 || p.potential < p.rating) p.potential = p.rating;
  }

  static bool retires(Player p, SeededRandom rng) {
    if (p.age >= 37) return true;
    if (p.age >= 34 && p.rating < 52) return rng.chance(0.5);
    if (p.age >= 35) return rng.chance(0.4);
    return false;
  }
}
