import 'models.dart';
import 'rng.dart';

class Pairing {
  final String home;
  final String away;
  const Pairing(this.home, this.away);
}

class FixtureGenerator {
  /// Double round-robin using the circle method. [ids] must have even length.
  /// Returns one list of pairings per matchday (2 * (n - 1) matchdays).
  static List<List<Pairing>> doubleRoundRobin(List<String> ids, int seed) {
    assert(ids.length.isEven && ids.length >= 2);
    final order = List<String>.from(ids);
    SeededRandom(seed).shuffle(order);
    final n = order.length;
    final rot = List<String>.from(order);
    final firstHalf = <List<Pairing>>[];
    for (var r = 0; r < n - 1; r++) {
      final round = <Pairing>[];
      for (var i = 0; i < n ~/ 2; i++) {
        var home = rot[i];
        var away = rot[n - 1 - i];
        // Slot 0 alternates opposite to the rest, which keeps every team's
        // home/away runs short (verified: never more than 2 in a row).
        final swap = i == 0 ? r.isEven : r.isOdd;
        if (swap) {
          final t = home;
          home = away;
          away = t;
        }
        round.add(Pairing(home, away));
      }
      firstHalf.add(round);
      rot.insert(1, rot.removeLast());
    }
    final secondHalf = firstHalf
        .map((round) => round.map((p) => Pairing(p.away, p.home)).toList())
        .toList();
    return [...firstHalf, ...secondHalf];
  }

  static List<Fixture> buildSeason(List<String> clubIds, int season, int seed) {
    final rounds = doubleRoundRobin(clubIds, mixSeed(seed, season));
    final fixtures = <Fixture>[];
    for (var md = 0; md < rounds.length; md++) {
      for (var i = 0; i < rounds[md].length; i++) {
        final p = rounds[md][i];
        fixtures.add(Fixture(
          id: 's$season-md${md + 1}-$i',
          season: season,
          matchday: md + 1,
          homeId: p.home,
          awayId: p.away,
        ));
      }
    }
    return fixtures;
  }
}
