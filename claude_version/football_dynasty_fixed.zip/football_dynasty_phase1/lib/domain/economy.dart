import 'dart:math' as math;
import 'models.dart';

enum BidStatus { accepted, countered, rejected, blocked }

class BidResponse {
  final BidStatus status;
  final int? counter;
  final String message;
  const BidResponse(this.status, this.message, {this.counter});
}

class Economy {
  static const minSquad = 16;
  static const maxSquad = 30;

  static int _roundTo(double v, int step, int min) =>
      math.max(min, (v / step).round() * step);

  /// Estimated market value in euros.
  static int value(Player p) {
    var v = 40000 * math.exp(0.19 * (p.rating - 50));
    if (p.age <= 23) {
      final gap = math.min(25, math.max(0, p.potential - p.rating));
      v *= 1 + gap * 0.035;
    }
    if (p.age >= 30) {
      v *= math.min(1.0, math.max(0.12, 1 - (p.age - 29) * 0.13));
    }
    return v >= 100000 ? _roundTo(v, 10000, 10000) : _roundTo(v, 1000, 1000);
  }

  /// Weekly wage a player of this quality typically commands.
  static int wageFor(Player p) =>
      _roundTo(1500 * math.exp(0.09 * (p.rating - 50)), 50, 500);

  /// Weekly wage the player asks for when renewing.
  static int renewalWage(Player p) {
    final market = wageFor(p);
    final base = math.max(p.wage, market);
    return _roundTo(base * (p.age < 30 ? 1.12 : 1.0), 50, 500);
  }

  static int renewalYears(Player p) => p.age < 30 ? 4 : 2;

  /// Compensation paid when releasing a player mid-contract.
  static int releaseCost(Player p) =>
      (p.wage * 52 * p.contractYears * 0.25).round();

  /// Fee the selling club asks for.
  static int askingPrice(Player p, List<Player> sellerSquad) {
    var mult = 1.10;
    final sorted = [...sellerSquad]..sort((a, b) => b.rating.compareTo(a.rating));
    final idx = sorted.indexWhere((x) => x.id == p.id);
    if (idx >= 0 && idx < 3) {
      mult += 0.25;
    } else if (idx >= 0 && idx < 8) {
      mult += 0.10;
    }
    final samePos = sellerSquad.where((x) => x.group == p.group).length;
    if (samePos <= 2) mult += 0.20;
    if (p.contractYears <= 1) mult -= 0.15;
    return _roundTo(value(p) * mult, 10000, 10000);
  }

  static BidResponse evaluateBid({
    required Player player,
    required int fee,
    required List<Player> sellerSquad,
  }) {
    if (sellerSquad.length <= minSquad + 1) {
      return const BidResponse(
          BidStatus.blocked, 'The club refuses to sell: their squad is too thin.');
    }
    final ask = askingPrice(player, sellerSquad);
    if (fee >= ask) {
      return const BidResponse(BidStatus.accepted, 'Bid accepted.');
    }
    if (fee >= ask * 0.85) {
      return BidResponse(BidStatus.countered, 'They want a little more.', counter: ask);
    }
    return const BidResponse(BidStatus.rejected, 'Bid rejected: far below their valuation.');
  }

  /// Whether a free agent is willing to join a club of this reputation.
  static bool freeAgentWilling(Player p, Club club) => p.rating <= club.reputation + 14;
}
