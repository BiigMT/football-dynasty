import 'models.dart';

class LineupSlot {
  final String slot; // formation position
  final Player player;
  const LineupSlot(this.slot, this.player);

  /// Rating used by the simulation, accounting for fitness, morale and
  /// playing out of position.
  double get effective {
    final fit = 0.80 + 0.20 * player.fitness / 100;
    final mor = 0.97 + 0.06 * player.morale / 100;
    return (player.rating - positionPenalty(player.position, slot)) * fit * mor;
  }
}

double positionPenalty(String playerPos, String slot) {
  if (playerPos == slot) return 0;
  if (groupOf(playerPos) == groupOf(slot)) {
    return groupOf(slot) == PositionGroup.gk ? 0 : 4;
  }
  if (groupOf(slot) == PositionGroup.gk) return 40;
  if (groupOf(playerPos) == PositionGroup.gk) return 40;
  return 12;
}

class LineupBuilder {
  /// Builds an XI for [tactics]. Manual picks in `tactics.lineup` are honoured
  /// when valid and available; empty slots are filled automatically.
  static List<LineupSlot> build(List<Player> squad, Tactics tactics) {
    final slots = formations[tactics.formation] ?? formations['4-3-3']!;
    final used = <String>{};
    final chosen = List<Player?>.filled(slots.length, null);

    // Manual picks first.
    for (var i = 0; i < slots.length && i < tactics.lineup.length; i++) {
      final id = tactics.lineup[i];
      if (id.isEmpty || used.contains(id)) continue;
      final p = squad.where((x) => x.id == id && x.isAvailable).toList();
      if (p.isNotEmpty) {
        chosen[i] = p.first;
        used.add(id);
      }
    }

    // Auto-fill remaining slots, scarcest first (GK, then others in order).
    final order = List<int>.generate(slots.length, (i) => i);
    for (final i in order) {
      if (chosen[i] != null) continue;
      final pool = squad.where((p) => p.isAvailable && !used.contains(p.id)).toList();
      final fallback = squad.where((p) => !used.contains(p.id)).toList();
      final candidates = pool.isNotEmpty ? pool : fallback;
      if (candidates.isEmpty) break;
      Player? best;
      var bestScore = -1e9;
      for (final p in candidates) {
        final score = LineupSlot(slots[i], p).effective;
        if (score > bestScore) {
          bestScore = score;
          best = p;
        }
      }
      chosen[i] = best;
      used.add(best!.id);
    }

    final result = <LineupSlot>[];
    for (var i = 0; i < slots.length; i++) {
      final p = chosen[i];
      if (p != null) result.add(LineupSlot(slots[i], p));
    }
    return result;
  }

  static double averageEffective(List<LineupSlot> xi) =>
      xi.isEmpty ? 0 : xi.fold<double>(0, (a, s) => a + s.effective) / xi.length;
}
