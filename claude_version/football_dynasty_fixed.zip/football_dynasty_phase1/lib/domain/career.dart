import 'dart:math' as math;
import 'economy.dart';
import 'fixtures.dart';
import 'league.dart' as lg;
import 'lineup.dart';
import 'match_engine.dart';
import 'models.dart';
import 'progression.dart';
import 'rng.dart';
import 'world_generator.dart';

/// Complete, serialisable state of one career save. All gameplay rules live
/// here (and in the domain classes it uses) so they can be tested without
/// Flutter and replayed from a seed.
class Career {
  static const schemaVersion = 1;
  static const startSeason = 2026;

  final int seed;
  String managerName;
  String userClubId;
  int season;
  int matchday; // next matchday to be played (1-based)
  int nextPlayerNumber;
  int offerCounter;
  int boardConfidence; // 0..100
  int objective; // target league position
  final Map<String, Club> clubs;
  final Map<String, Player> players;
  List<Fixture> fixtures;
  List<TransferOffer> offers;
  List<NewsItem> news;
  Set<String> shortlist;
  MatchResult? lastUserMatch;
  List<SeasonRecord> history;

  Career._({
    required this.seed,
    required this.managerName,
    required this.userClubId,
    required this.season,
    required this.matchday,
    required this.nextPlayerNumber,
    required this.offerCounter,
    required this.boardConfidence,
    required this.objective,
    required this.clubs,
    required this.players,
    required this.fixtures,
    required this.offers,
    required this.news,
    required this.shortlist,
    required this.lastUserMatch,
    required this.history,
  });

  factory Career.newGame({
    required String managerName,
    required String userClubId,
    required int seed,
  }) {
    final clubs = <String, Club>{};
    final players = <String, Player>{};
    final next = WorldGenerator.generate(seed: seed, clubs: clubs, players: players);
    final career = Career._(
      seed: seed,
      managerName: managerName,
      userClubId: userClubId,
      season: startSeason,
      matchday: 1,
      nextPlayerNumber: next,
      offerCounter: 0,
      boardConfidence: 60,
      objective: 1,
      clubs: clubs,
      players: players,
      fixtures: FixtureGenerator.buildSeason(clubs.keys.toList(), startSeason, seed),
      offers: [],
      news: [],
      shortlist: {},
      lastUserMatch: null,
      history: [],
    );
    career.objective = career._computeObjective();
    career._addNews('${career.userClub.name} appoint $managerName as manager. '
        'The board expect a top-${career.objective} finish.');
    return career;
  }

  // ---------------------------------------------------------------- queries

  Club get userClub => clubs[userClubId]!;
  int get totalMatchdays => (clubs.length - 1) * 2;
  bool get seasonComplete => matchday > totalMatchdays;
  String get seasonLabel => '$season/${(season + 1).toString().substring(2)}';

  List<Player> squad(String clubId) =>
      players.values.where((p) => p.clubId == clubId).toList();
  List<Player> get userSquad => squad(userClubId);
  List<Player> get freeAgents => players.values.where((p) => p.clubId == null).toList();
  int wageBill(String clubId) => squad(clubId).fold<int>(0, (a, p) => a + p.wage);

  List<Fixture> fixturesForMatchday(int md) =>
      fixtures.where((f) => f.season == season && f.matchday == md).toList();

  Fixture? get nextUserFixture {
    if (seasonComplete) return null;
    for (final f in fixturesForMatchday(matchday)) {
      if (f.involves(userClubId)) return f;
    }
    return null;
  }

  List<lg.TableRow> get table => lg.League.table(fixtures, clubs, season);
  int get userPosition => table.indexWhere((r) => r.clubId == userClubId) + 1;

  String? get windowName {
    if (seasonComplete) return null;
    if (matchday <= 4) return 'Summer';
    if (matchday >= 16 && matchday <= 18) return 'Winter';
    return null;
  }

  bool get isWindowOpen => windowName != null;

  double _quickStrength(List<Player> squad) {
    final sorted = squad.where((p) => p.isAvailable).map((p) => p.rating).toList()
      ..sort((a, b) => b.compareTo(a));
    final top = sorted.take(11).toList();
    return top.isEmpty ? 0 : top.reduce((a, b) => a + b) / top.length;
  }

  int _computeObjective() {
    final ranked = clubs.keys.toList()
      ..sort((a, b) => _quickStrength(squad(b)).compareTo(_quickStrength(squad(a))));
    final rank = ranked.indexOf(userClubId) + 1;
    return math.max(1, (rank * 0.8).ceil());
  }

  /// Potential is only exact for your own players; others are scouted estimates.
  String potentialLabel(Player p) {
    if (p.clubId == userClubId) return '${p.potential}';
    final noise = (hashString(p.id) % 7) - 3; // -3..+3, stable per player
    final lo = math.max(p.rating, p.potential + noise - 3);
    final hi = math.min(99, math.max(lo, p.potential + noise + 3));
    return lo == hi ? '$lo' : '$lo-$hi';
  }

  void _addNews(String text) {
    news.insert(0, NewsItem(season, matchday, text));
    if (news.length > 40) news.removeRange(40, news.length);
  }

  // ------------------------------------------------------------- match flow

  Tactics _tacticsFor(Club club, List<Player> squad, double opponentStrength) {
    if (club.id == userClubId) return club.tactics;
    final diff = _quickStrength(squad) - opponentStrength;
    final mentality = diff > 4 ? 2 : (diff < -6 ? 0 : 1);
    return Tactics(formation: club.tactics.formation, mentality: mentality);
  }

  /// Plays the next matchday for every club. Returns the user's match.
  MatchResult? playMatchday() {
    if (seasonComplete) return null;
    final md = matchday;
    MatchResult? userResult;
    final pendingInjuries = <String, int>{};
    final pendingSuspensions = <String, int>{};

    for (final f in fixturesForMatchday(md)) {
      final home = clubs[f.homeId]!;
      final away = clubs[f.awayId]!;
      final homeSquad = squad(home.id);
      final awaySquad = squad(away.id);
      final homeTactics = _tacticsFor(home, homeSquad, _quickStrength(awaySquad));
      final awayTactics = _tacticsFor(away, awaySquad, _quickStrength(homeSquad));
      final homeSheet =
          TeamSheet(home, LineupBuilder.build(homeSquad, homeTactics), homeTactics);
      final awaySheet =
          TeamSheet(away, LineupBuilder.build(awaySquad, awayTactics), awayTactics);
      final result = MatchEngine.simulate(
        fixtureId: f.id,
        home: homeSheet,
        away: awaySheet,
        seed: mixSeed(mixSeed(seed, season), md * 100 + fixtures.indexOf(f)),
      );

      f.homeGoals = result.homeGoals;
      f.awayGoals = result.awayGoals;
      f.scorers = result.events
          .where((e) => e.type == EventType.goal && e.playerId != null)
          .map((e) => GoalRecord(e.playerId!, e.clubId!, e.minute))
          .toList();

      _applyPlayerEffects(homeSheet, result.homeGoals, result.awayGoals);
      _applyPlayerEffects(awaySheet, result.awayGoals, result.homeGoals);

      for (final e in result.events.where((e) => e.type == EventType.goal)) {
        final p = players[e.playerId];
        if (p != null) p.goals++;
      }
      result.newInjuries.forEach((id, out) => pendingInjuries[id] = out);
      for (final id in result.yellowCardPlayers) {
        final p = players[id];
        if (p == null) continue;
        p.yellowCards++;
        if (p.yellowCards >= 5) {
          p.yellowCards = 0;
          pendingSuspensions[id] = math.max(pendingSuspensions[id] ?? 0, 1);
        }
      }
      for (final id in result.redCardPlayers) {
        pendingSuspensions[id] = math.max(pendingSuspensions[id] ?? 0, 1);
      }

      if (f.involves(userClubId)) {
        userResult = result;
        _applyFinances(f);
      }
    }

    // Serve existing absences, then apply the new ones.
    for (final p in players.values) {
      if (p.injuredMatches > 0) p.injuredMatches--;
      if (p.suspendedMatches > 0) p.suspendedMatches--;
      // Weekly recovery for everyone.
      p.fitness = math.min(100, p.fitness + 12);
    }
    pendingInjuries.forEach((id, out) {
      final p = players[id];
      if (p != null) p.injuredMatches = out;
    });
    pendingSuspensions.forEach((id, out) {
      final p = players[id];
      if (p != null) p.suspendedMatches = math.max(p.suspendedMatches, out);
    });

    lastUserMatch = userResult;
    if (userResult != null) _reportUserMatch(userResult);

    matchday++;
    _refreshOffers();
    return userResult;
  }

  void _applyPlayerEffects(TeamSheet sheet, int goalsFor, int goalsAgainst) {
    final drain = 14 + 2 * sheet.tactics.pressing;
    final starters = sheet.xi.map((s) => s.player.id).toSet();
    final moraleShift = goalsFor > goalsAgainst ? 4 : (goalsFor < goalsAgainst ? -5 : 0);
    for (final p in squad(sheet.club.id)) {
      if (starters.contains(p.id)) {
        p.appearances++;
        p.fitness = math.max(40, p.fitness - drain);
      }
      final drift = ((60 - p.morale) * 0.05).round();
      p.morale = math.max(20, math.min(100, p.morale + moraleShift + drift));
    }
  }

  void _applyFinances(Fixture f) {
    final club = userClub;
    final tv = club.reputation * 1400;
    var gate = 0;
    if (f.homeId == userClubId) {
      final attendance = clampD(0.55 + club.reputation / 200, 0.4, 1.0);
      final price = 20 + club.reputation * 0.2;
      gate = (club.stadiumCapacity * attendance * price).round();
    }
    final wasPositive = club.balance >= 0;
    club.balance += tv + gate - wageBill(userClubId) - 60000;
    if (wasPositive && club.balance < 0) {
      _addNews('The board are concerned: the club balance is now negative.');
    }
  }

  void _reportUserMatch(MatchResult r) {
    final home = clubs[r.homeId]!.name;
    final away = clubs[r.awayId]!.name;
    _addNews('Result: $home ${r.homeGoals}-${r.awayGoals} $away');
    for (final id in r.newInjuries.keys) {
      final p = players[id];
      if (p != null && p.clubId == userClubId) {
        _addNews('${p.name} is injured and will miss ${r.newInjuries[id]} match(es).');
      }
    }
    for (final id in r.redCardPlayers) {
      final p = players[id];
      if (p != null && p.clubId == userClubId) {
        _addNews('${p.name} is suspended for the next match.');
      }
    }
  }

  /// Plays the remaining fixtures of the season without stopping.
  void simulateToSeasonEnd() {
    while (!seasonComplete) {
      playMatchday();
    }
  }

  // --------------------------------------------------------------- transfers

  void _refreshOffers() {
    offers.removeWhere((o) => o.season != season || o.expiresMatchday < matchday);
    if (!isWindowOpen || offers.length >= 3) return;
    final rng = SeededRandom(mixSeed(mixSeed(seed, season), 9000 + matchday));
    if (!rng.chance(0.35)) return;
    final sorted = userSquad..sort((a, b) => b.rating.compareTo(a.rating));
    if (sorted.length <= Economy.minSquad + 1) return;
    final target = rng.pick(sorted.take(14).toList());
    if (offers.any((o) => o.playerId == target.id)) return;
    final buyers = clubs.values.where((c) => c.id != userClubId).toList();
    final buyer = rng.pick(buyers);
    final fee = ((target.value * (0.8 + 0.5 * rng.nextDouble())) / 10000).round() * 10000;
    offers.add(TransferOffer(
      id: 'o${offerCounter++}',
      playerId: target.id,
      fromClubId: buyer.id,
      fee: math.max(10000, fee),
      expiresMatchday: matchday + 2,
      season: season,
    ));
    _addNews('${buyer.name} have made an offer for ${target.name}.');
  }

  ActionResult acceptOffer(String offerId) {
    final idx = offers.indexWhere((o) => o.id == offerId);
    if (idx < 0) return const ActionResult(false, 'That offer is no longer available.');
    final o = offers[idx];
    final p = players[o.playerId];
    if (p == null || p.clubId != userClubId) {
      offers.removeAt(idx);
      return const ActionResult(false, 'The player is no longer at your club.');
    }
    if (userSquad.length <= Economy.minSquad) {
      return ActionResult(false,
          'You need at least ${Economy.minSquad} players. Sign a replacement first.');
    }
    _moveToClub(p, o.fromClubId, o.fee, selling: true);
    offers.removeAt(idx);
    _addNews('${p.name} sold to ${clubs[o.fromClubId]!.name} for ${_money(o.fee)}.');
    return ActionResult(true, '${p.name} sold for ${_money(o.fee)}.');
  }

  void rejectOffer(String offerId) => offers.removeWhere((o) => o.id == offerId);

  void _moveToClub(Player p, String toClubId, int fee, {required bool selling}) {
    final fromClubId = p.clubId;
    p.clubId = toClubId;
    p.contractYears = 3;
    p.morale = 70;
    if (!selling) {
      p.wage = Economy.wageFor(p);
      userClub.balance -= fee;
      userClub.transferBudget -= fee;
      if (fromClubId != null) clubs[fromClubId]?.balance += fee;
    } else {
      userClub.balance += fee;
      userClub.transferBudget += fee;
    }
    shortlist.remove(p.id);
    final rng = SeededRandom(mixSeed(seed, nextPlayerNumber));
    for (final id in [fromClubId, toClubId]) {
      if (id != null && id != userClubId) _ensureSquadDepth(id, rng);
    }
  }

  BidResponse bid(String playerId, int fee) {
    final p = players[playerId];
    if (p == null || p.clubId == null || p.clubId == userClubId) {
      return const BidResponse(BidStatus.blocked, 'This player cannot be bought.');
    }
    if (!isWindowOpen) {
      return const BidResponse(BidStatus.blocked, 'The transfer window is closed.');
    }
    if (userSquad.length >= Economy.maxSquad) {
      return const BidResponse(BidStatus.blocked, 'Your squad is full (30 players).');
    }
    final uc = userClub;
    if (fee > uc.transferBudget || fee > uc.balance) {
      return const BidResponse(BidStatus.blocked, 'You cannot afford this fee.');
    }
    if (wageBill(userClubId) + Economy.wageFor(p) > uc.wageBudget) {
      return const BidResponse(BidStatus.blocked, 'This would exceed your wage budget.');
    }
    final response =
        Economy.evaluateBid(player: p, fee: fee, sellerSquad: squad(p.clubId!));
    if (response.status == BidStatus.accepted) {
      final from = clubs[p.clubId!]!.name;
      _moveToClub(p, userClubId, fee, selling: false);
      _addNews('${p.name} signs from $from for ${_money(fee)}.');
    }
    return response;
  }

  ActionResult signFreeAgent(String playerId) {
    final p = players[playerId];
    if (p == null || p.clubId != null) {
      return const ActionResult(false, 'That player is not a free agent.');
    }
    if (userSquad.length >= Economy.maxSquad) {
      return const ActionResult(false, 'Your squad is full (30 players).');
    }
    if (!Economy.freeAgentWilling(p, userClub)) {
      return ActionResult(false, '${p.name} is not interested in joining your club.');
    }
    final wage = Economy.wageFor(p);
    if (wageBill(userClubId) + wage > userClub.wageBudget) {
      return const ActionResult(false, 'This would exceed your wage budget.');
    }
    p.clubId = userClubId;
    p.wage = wage;
    p.contractYears = 2;
    p.morale = 70;
    shortlist.remove(p.id);
    _addNews('${p.name} signs as a free agent.');
    return ActionResult(true, '${p.name} has joined on a free transfer.');
  }

  ActionResult releasePlayer(String playerId) {
    final p = players[playerId];
    if (p == null || p.clubId != userClubId) {
      return const ActionResult(false, 'Player not found in your squad.');
    }
    if (userSquad.length <= Economy.minSquad) {
      return ActionResult(false, 'You need at least ${Economy.minSquad} players.');
    }
    final cost = Economy.releaseCost(p);
    if (cost > userClub.balance) {
      return ActionResult(false, 'You cannot afford the ${_money(cost)} compensation.');
    }
    userClub.balance -= cost;
    p.clubId = null;
    p.contractYears = 0;
    _addNews('${p.name} released (compensation ${_money(cost)}).');
    return ActionResult(true, '${p.name} released.');
  }

  ActionResult renewContract(String playerId) {
    final p = players[playerId];
    if (p == null || p.clubId != userClubId) {
      return const ActionResult(false, 'Player not found in your squad.');
    }
    final wage = Economy.renewalWage(p);
    if (wageBill(userClubId) - p.wage + wage > userClub.wageBudget) {
      return const ActionResult(false, 'This would exceed your wage budget.');
    }
    p.wage = wage;
    p.contractYears = Economy.renewalYears(p);
    p.morale = math.min(100, p.morale + 5);
    return ActionResult(true, '${p.name} signed until ${season + p.contractYears}.');
  }

  void toggleShortlist(String playerId) {
    if (!shortlist.remove(playerId)) shortlist.add(playerId);
  }

  void setTactics(Tactics t) => userClub.tactics = t;

  // ------------------------------------------------------------- season end

  void _ensureSquadDepth(String clubId, SeededRandom rng) {
    final squadNow = squad(clubId);
    WorldGenerator.squadTemplate.forEach((pos, count) {
      final have = squadNow.where((p) => p.position == pos).length;
      for (var i = have; i < count; i++) {
        final y = WorldGenerator.generateYouth(rng, nextPlayerNumber++, pos, clubId);
        players[y.id] = y;
      }
    });
  }

  /// Promotes academy youngsters so the user is never left unable to field a team.
  void _academyTopUp(SeededRandom rng) {
    const minimum = 18;
    var added = 0;
    while (userSquad.length < minimum) {
      final current = userSquad;
      String? needPos;
      var worstGap = 0;
      WorldGenerator.squadTemplate.forEach((pos, count) {
        final gap = count - current.where((p) => p.position == pos).length;
        if (gap > worstGap) {
          worstGap = gap;
          needPos = pos;
        }
      });
      final pos = needPos ?? rng.pick(allPositions);
      final String safePosition = pos ?? 'CM';
final y = WorldGenerator.generateYouth(rng, nextPlayerNumber++, safePosition, clubId);
      players[y.id] = y;
      added++;
    }
    if (added > 0) {
      _addNews('The academy promoted $added youngster(s) to keep the squad at $minimum players.');
    }
  }

  ActionResult startNextSeason() {
    if (!seasonComplete) {
      return const ActionResult(false, 'The season is not finished yet.');
    }
    final rows = table;
    final pos = rows.indexWhere((r) => r.clubId == userClubId) + 1;
    final userRow = rows[pos - 1];
    history.add(SeasonRecord(
      season: season,
      championId: rows.first.clubId,
      userPosition: pos,
      userPoints: userRow.points,
      objective: objective,
    ));

    // Board verdict.
    final met = pos <= objective;
    if (met) {
      boardConfidence = math.min(100, boardConfidence + 10);
      userClub.reputation = math.min(99, userClub.reputation + 1);
    } else {
      boardConfidence = math.max(0, boardConfidence - (pos > objective + 3 ? 20 : 10));
      userClub.reputation = math.max(1, userClub.reputation - 1);
    }
    final prize = (clubs.length - pos) * 250000;
    userClub.balance += prize;
    userClub.transferBudget += (prize * 0.6).round();
    _addNews('Season $seasonLabel finished: ${userClub.name} in position $pos. '
        '${met ? 'Objective achieved.' : 'The board are disappointed.'} '
        'Prize money ${_money(prize)}.');

    // Ageing, retirement and contracts.
    final rng = SeededRandom(mixSeed(seed, season * 7 + 3));
    for (final p in players.values.toList()) {
      Progression.ageOneYear(p, rng);
      p.appearances = 0;
      p.goals = 0;
      p.yellowCards = 0;
      p.injuredMatches = 0;
      p.suspendedMatches = 0;
      p.fitness = 100;
      p.morale = 65;
      if (Progression.retires(p, rng)) {
        if (p.clubId == userClubId) _addNews('${p.name} has retired from football.');
        players.remove(p.id);
        shortlist.remove(p.id);
        continue;
      }
      if (p.clubId == null) continue;
      p.contractYears--;
      if (p.contractYears <= 0) {
        if (p.clubId == userClubId) {
          _addNews('${p.name}\'s contract expired and he left the club.');
          p.clubId = null;
          p.contractYears = 0;
        } else {
          p.wage = Economy.renewalWage(p);
          p.contractYears = rng.range(2, 4);
        }
      }
    }

    // Free-agent pool: drop the weakest if oversized, then add new faces.
    final pool = freeAgents..sort((a, b) => b.rating.compareTo(a.rating));
    for (final p in pool.skip(35)) {
      players.remove(p.id);
      shortlist.remove(p.id);
    }
    nextPlayerNumber = WorldGenerator.generateFreeAgents(
        rng: rng, players: players, startNumber: nextPlayerNumber, count: 25);

    for (final id in clubs.keys) {
      if (id != userClubId) _ensureSquadDepth(id, rng);
    }
    _academyTopUp(rng);

    season++;
    matchday = 1;
    fixtures = [
      ...fixtures,
      ...FixtureGenerator.buildSeason(clubs.keys.toList(), season, seed),
    ];
    // Keep only the last two seasons of fixtures to bound save size.
    fixtures.removeWhere((f) => f.season < season - 1);
    offers = [];
    lastUserMatch = null;
    objective = _computeObjective();
    _addNews('Season $seasonLabel begins. Target: top $objective.');
    return ActionResult(true, 'Season $seasonLabel started.');
  }

  static String _money(int v) {
    final a = v.abs();
    if (a >= 1000000) return '€${(v / 1000000).toStringAsFixed(1)}M';
    if (a >= 1000) return '€${(v / 1000).round()}K';
    return '€$v';
  }

  // ---------------------------------------------------------- serialisation

  Map<String, dynamic> toJson() => {
        'version': schemaVersion,
        'seed': seed,
        'manager': managerName,
        'userClub': userClubId,
        'season': season,
        'matchday': matchday,
        'nextPlayer': nextPlayerNumber,
        'offerCounter': offerCounter,
        'board': boardConfidence,
        'objective': objective,
        'clubs': clubs.values.map((c) => c.toJson()).toList(),
        'players': players.values.map((p) => p.toJson()).toList(),
        'fixtures': fixtures.map((f) => f.toJson()).toList(),
        'offers': offers.map((o) => o.toJson()).toList(),
        'news': news.map((n) => n.toJson()).toList(),
        'shortlist': shortlist.toList(),
        'lastMatch': lastUserMatch?.toJson(),
        'history': history.map((h) => h.toJson()).toList(),
      };

  factory Career.fromJson(Map<String, dynamic> j) {
    final version = j['version'] as int? ?? 0;
    if (version > schemaVersion) {
      throw FormatException('Save was created by a newer version of the game ($version).');
    }
    List<T> list<T>(String key, T Function(Map<String, dynamic>) f) =>
        (j[key] as List).map((e) => f(e as Map<String, dynamic>)).toList();
    return Career._(
      seed: j['seed'] as int,
      managerName: j['manager'] as String,
      userClubId: j['userClub'] as String,
      season: j['season'] as int,
      matchday: j['matchday'] as int,
      nextPlayerNumber: j['nextPlayer'] as int,
      offerCounter: j['offerCounter'] as int,
      boardConfidence: j['board'] as int,
      objective: j['objective'] as int,
      clubs: {for (final c in list('clubs', Club.fromJson)) c.id: c},
      players: {for (final p in list('players', Player.fromJson)) p.id: p},
      fixtures: list('fixtures', Fixture.fromJson),
      offers: list('offers', TransferOffer.fromJson),
      news: list('news', NewsItem.fromJson),
      shortlist: (j['shortlist'] as List).cast<String>().toSet(),
      lastUserMatch: j['lastMatch'] == null
          ? null
          : MatchResult.fromJson(j['lastMatch'] as Map<String, dynamic>),
      history: list('history', SeasonRecord.fromJson),
    );
  }
}
