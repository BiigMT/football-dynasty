import 'models.dart';

class TableRow {
  final String clubId;
  int played = 0, won = 0, drawn = 0, lost = 0, goalsFor = 0, goalsAgainst = 0;
  TableRow(this.clubId);

  int get points => won * 3 + drawn;
  int get goalDifference => goalsFor - goalsAgainst;
}

class ScorerRow {
  final String playerId;
  final int goals;
  const ScorerRow(this.playerId, this.goals);
}

class League {
  /// Computes the table from played fixtures of [season].
  /// Ties are broken by goal difference, goals scored, then club name.
  static List<TableRow> table(
      List<Fixture> fixtures, Map<String, Club> clubs, int season) {
    final rows = {for (final id in clubs.keys) id: TableRow(id)};
    for (final f in fixtures) {
      if (f.season != season || !f.played) continue;
      final h = rows[f.homeId]!;
      final a = rows[f.awayId]!;
      final hg = f.homeGoals!, ag = f.awayGoals!;
      h.played++;
      a.played++;
      h.goalsFor += hg;
      h.goalsAgainst += ag;
      a.goalsFor += ag;
      a.goalsAgainst += hg;
      if (hg > ag) {
        h.won++;
        a.lost++;
      } else if (hg < ag) {
        a.won++;
        h.lost++;
      } else {
        h.drawn++;
        a.drawn++;
      }
    }
    final list = rows.values.toList()
      ..sort((x, y) {
        final p = y.points.compareTo(x.points);
        if (p != 0) return p;
        final gd = y.goalDifference.compareTo(x.goalDifference);
        if (gd != 0) return gd;
        final gf = y.goalsFor.compareTo(x.goalsFor);
        if (gf != 0) return gf;
        return clubs[x.clubId]!.name.compareTo(clubs[y.clubId]!.name);
      });
    return list;
  }

  static List<ScorerRow> topScorers(List<Fixture> fixtures, int season, {int limit = 15}) {
    final counts = <String, int>{};
    for (final f in fixtures) {
      if (f.season != season) continue;
      for (final g in f.scorers) {
        counts[g.playerId] = (counts[g.playerId] ?? 0) + 1;
      }
    }
    final rows = counts.entries.map((e) => ScorerRow(e.key, e.value)).toList()
      ..sort((a, b) => b.goals.compareTo(a.goals));
    return rows.take(limit).toList();
  }
}
