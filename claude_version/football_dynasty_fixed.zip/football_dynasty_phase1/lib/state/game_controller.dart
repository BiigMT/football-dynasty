import 'package:flutter/material.dart';
import '../data/save_store.dart';
import '../domain/career.dart';
import '../domain/economy.dart';
import '../domain/models.dart';

/// Bridges the domain model and the UI. Every mutation goes through [run],
/// which notifies listeners and writes the save to local storage (offline-first).
class GameController extends ChangeNotifier {
  final SaveStore store;
  Career? career;
  int? slot;
  bool loading = true;
  List<SaveSummary?> summaries = List<SaveSummary?>.filled(SaveStore.slotCount, null);
  Future<void> _saveQueue = Future.value();

  GameController(this.store);

  Future<void> init() async {
    summaries = await store.summaries();
    loading = false;
    notifyListeners();
  }

  Future<void> loadSlot(int s) async {
    final c = await store.load(s);
    if (c == null) return;
    career = c;
    slot = s;
    notifyListeners();
  }

  Future<void> startCareer(int s, String manager, String clubId, int seed) async {
    career = Career.newGame(managerName: manager, userClubId: clubId, seed: seed);
    slot = s;
    await store.save(s, career!);
    summaries = await store.summaries();
    notifyListeners();
  }

  Future<void> exitToMenu() async {
    await _saveQueue;
    career = null;
    slot = null;
    summaries = await store.summaries();
    notifyListeners();
  }

  Future<void> deleteSlot(int s) async {
    await store.delete(s);
    summaries = await store.summaries();
    notifyListeners();
  }

  T run<T>(T Function(Career c) action) {
    final c = career!;
    final result = action(c);
    notifyListeners();
    final s = slot;
    if (s != null) {
      _saveQueue = _saveQueue.then((_) => store.save(s, c)).catchError((Object _) {});
    }
    return result;
  }

  // Convenience wrappers used by screens.
  MatchResult? playMatchday() => run((c) => c.playMatchday());
  void simulateSeason() => run((c) => c.simulateToSeasonEnd());
  ActionResult startNextSeason() => run((c) => c.startNextSeason());
  BidResponse bid(String id, int fee) => run((c) => c.bid(id, fee));
  ActionResult signFreeAgent(String id) => run((c) => c.signFreeAgent(id));
  ActionResult release(String id) => run((c) => c.releasePlayer(id));
  ActionResult renew(String id) => run((c) => c.renewContract(id));
  ActionResult acceptOffer(String id) => run((c) => c.acceptOffer(id));
  void rejectOffer(String id) => run((c) => c.rejectOffer(id));
  void toggleShortlist(String id) => run((c) => c.toggleShortlist(id));
  void setTactics(Tactics t) => run((c) => c.setTactics(t));
}

class GameScope extends InheritedNotifier<GameController> {
  const GameScope({super.key, required GameController controller, required super.child})
      : super(notifier: controller);

  static GameController of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<GameScope>()!.notifier!;
}
