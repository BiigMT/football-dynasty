import 'package:flutter/material.dart';
import '../domain/career.dart';
import '../state/game_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class StartScreen extends StatelessWidget {
  const StartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final game = GameScope.of(context);
    return Scaffold(
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(18), children: [
          const ScreenHeader(kicker: 'FOOTBALL DYNASTY', title: 'Career saves'),
          const SizedBox(height: 6),
          const Text('Plays fully offline. Saves are stored on this device.',
              style: TextStyle(color: Colors.white60)),
          const SizedBox(height: 18),
          for (var i = 0; i < game.summaries.length; i++) _slot(context, game, i + 1),
          const SizedBox(height: 16),
          const Text(
              'All clubs, players and competitions are fictional generated data. '
              'No real-world names, crests or kits are used.',
              style: TextStyle(color: Colors.white38, fontSize: 11)),
        ]),
      ),
    );
  }

  Widget _slot(BuildContext context, GameController game, int slot) {
    final s = game.summaries[slot - 1];
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: s == null
              ? Row(children: [
                  Expanded(child: Text('Slot $slot - empty', style: const TextStyle(fontWeight: FontWeight.bold))),
                  FilledButton(
                    onPressed: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => NewCareerScreen(slot: slot))),
                    child: const Text('New career'),
                  ),
                ])
              : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Slot $slot', style: const TextStyle(color: AppTheme.green, fontSize: 11, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(s.clubName, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                  Text('${s.managerName} • Season ${s.seasonLabel} • Matchday ${s.matchday}',
                      style: const TextStyle(color: Colors.white60)),
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(child: FilledButton(onPressed: () => game.loadSlot(slot), child: const Text('Continue'))),
                    const SizedBox(width: 10),
                    OutlinedButton(
                      onPressed: () async {
                        final ok = await confirm(context, 'Delete save?',
                            'This permanently deletes the career in slot $slot.',
                            action: 'Delete');
                        if (ok) await game.deleteSlot(slot);
                      },
                      child: const Text('Delete'),
                    ),
                  ]),
                ]),
        ),
      ),
    );
  }
}

class NewCareerScreen extends StatefulWidget {
  final int slot;
  const NewCareerScreen({super.key, required this.slot});

  @override
  State<NewCareerScreen> createState() => _NewCareerScreenState();
}

class _NewCareerScreenState extends State<NewCareerScreen> {
  final nameController = TextEditingController(text: 'Manager');
  late final int seed = DateTime.now().millisecondsSinceEpoch & 0x7FFFFFFF;
  late final Career preview =
      Career.newGame(managerName: 'preview', userClubId: 'c01', seed: seed);
  String? selected;
  bool starting = false;

  @override
  void dispose() {
    nameController.dispose();
    super.dispose();
  }

  double _avg(String clubId) {
    final r = preview.squad(clubId).map((p) => p.rating).toList()..sort((a, b) => b.compareTo(a));
    final top = r.take(11);
    return top.reduce((a, b) => a + b) / top.length;
  }

  @override
  Widget build(BuildContext context) {
    final clubs = preview.clubs.values.toList()
      ..sort((a, b) => b.reputation.compareTo(a.reputation));
    return Scaffold(
      appBar: AppBar(title: const Text('New career')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 8),
          child: TextField(
            controller: nameController,
            maxLength: 30,
            decoration: const InputDecoration(labelText: 'Manager name', border: OutlineInputBorder()),
          ),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 18),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text('Choose your club', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ),
        Expanded(
          child: ListView(padding: const EdgeInsets.all(18), children: [
            for (final c in clubs)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18),
                    side: BorderSide(
                        color: selected == c.id ? AppTheme.green : Colors.transparent, width: 2),
                  ),
                  child: ListTile(
                    onTap: () => setState(() => selected = c.id),
                    leading: ClubCrest(c.shortName, c.colorValue),
                    title: Text(c.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(
                        'Reputation ${c.reputation} • Squad ${_avg(c.id).toStringAsFixed(0)} • ${fmtMoney(c.transferBudget)} to spend'),
                  ),
                ),
              ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.all(18),
          child: SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: selected == null || starting
                  ? null
                  : () async {
                      setState(() => starting = true);
                      final game = GameScope.of(context);
                      final nav = Navigator.of(context);
                      final name = nameController.text.trim().isEmpty
                          ? 'Manager'
                          : nameController.text.trim();
                      await game.startCareer(widget.slot, name, selected!, seed);
                      nav.popUntil((r) => r.isFirst);
                    },
              child: const Text('START CAREER'),
            ),
          ),
        ),
      ]),
    );
  }
}
