import 'package:flutter/material.dart';
import '../domain/models.dart';
import '../state/game_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import 'match_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final game = GameScope.of(context);
    final c = game.career!;
    final club = c.userClub;
    final rows = c.table;
    final myRow = rows.firstWhere((r) => r.clubId == c.userClubId);
    final squad = c.userSquad;
    final injured = squad.where((p) => p.injuredMatches > 0).length;
    final suspended = squad.where((p) => p.suspendedMatches > 0).length;
    final expiring = squad.where((p) => p.contractYears <= 1).length;
    final fx = c.nextUserFixture;

    return ListView(padding: const EdgeInsets.fromLTRB(18, 18, 18, 28), children: [
      ScreenHeader(
        kicker: 'MANAGER DASHBOARD',
        title: c.managerName,
        trailing: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () => _menu(context, game),
        ),
      ),
      const SizedBox(height: 18),
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(colors: [Color(0xFF203B4B), Color(0xFF142638)]),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            ClubCrest(club.shortName, club.colorValue),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(club.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                Text('Season ${c.seasonLabel} • Fictional league',
                    style: const TextStyle(color: Colors.white70)),
              ]),
            ),
          ]),
          const SizedBox(height: 20),
          Row(children: [
            _Metric('POSITION', '${c.userPosition}'),
            _Metric('POINTS', '${myRow.points}'),
            _Metric('BALANCE', fmtMoney(club.balance)),
          ]),
        ]),
      ),
      const SizedBox(height: 22),
      if (c.seasonComplete) _seasonEnd(context, game) else _nextFixture(context, game, fx),
      const SectionLabel('CLUB OVERVIEW'),
      GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 1.8,
        children: [
          _Tile(Icons.groups, 'First team', '${squad.length} players'),
          _Tile(Icons.account_balance_wallet, 'Wages',
              '${fmtMoney(c.wageBill(c.userClubId))} / ${fmtMoney(club.wageBudget)}'),
          _Tile(Icons.swap_horiz, 'Transfer budget', fmtMoney(club.transferBudget)),
          _Tile(Icons.flag, 'Board objective',
              'Top ${c.objective} • Trust ${c.boardConfidence}%'),
        ],
      ),
      if (injured + suspended + expiring > 0) ...[
        const SectionLabel('ATTENTION'),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (injured > 0) Text('• $injured injured player(s)'),
              if (suspended > 0) Text('• $suspended suspended player(s)'),
              if (expiring > 0) Text('• $expiring contract(s) expire at the end of this season'),
            ]),
          ),
        ),
      ],
      const SectionLabel('INBOX'),
      Card(
        child: Column(children: [
          for (final n in c.news.take(6))
            ListTile(
              dense: true,
              title: Text(n.text, style: const TextStyle(fontSize: 13)),
              subtitle: Text('Matchday ${n.matchday}',
                  style: const TextStyle(fontSize: 10, color: Colors.white38)),
            ),
        ]),
      ),
      const SizedBox(height: 16),
      const Text('All names, clubs and figures are fictional generated data.',
          style: TextStyle(color: Colors.white38, fontSize: 11)),
    ]);
  }

  Widget _nextFixture(BuildContext context, GameController game, Fixture? fx) {
    final c = game.career!;
    if (fx == null) return const SizedBox.shrink();
    final home = c.clubs[fx.homeId]!;
    final away = c.clubs[fx.awayId]!;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('Next fixture', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        Text('LEAGUE • MATCHDAY ${c.matchday}/${c.totalMatchdays}',
            style: const TextStyle(fontSize: 10, color: Colors.white54)),
      ]),
      const SizedBox(height: 10),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              _Team(home.name, home.shortName, home.colorValue),
              const Text('VS', style: TextStyle(color: Colors.white54, fontWeight: FontWeight.w800)),
              _Team(away.name, away.shortName, away.colorValue),
            ]),
            const SizedBox(height: 14),
            Text(fx.homeId == c.userClubId ? 'Home' : 'Away',
                style: const TextStyle(color: Colors.white60, fontSize: 12)),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () {
                  final result = game.playMatchday();
                  if (result != null) {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (_) => MatchScreen(result: result)));
                  }
                },
                icon: const Icon(Icons.play_arrow),
                label: const Text('PLAY MATCH'),
              ),
            ),
            TextButton(
              onPressed: () async {
                final ok = await confirm(context, 'Simulate season?',
                    'Plays every remaining matchday using your current tactics and lineup.',
                    action: 'Simulate');
                if (ok) game.simulateSeason();
              },
              child: const Text('Simulate to end of season'),
            ),
          ]),
        ),
      ),
    ]);
  }

  Widget _seasonEnd(BuildContext context, GameController game) {
    final c = game.career!;
    final pos = c.userPosition;
    final champ = c.clubs[c.table.first.clubId]!;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Season ${c.seasonLabel} complete',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text('Champions: ${champ.name}', style: const TextStyle(color: AppTheme.gold)),
          Text('You finished $pos${_ord(pos)} (target: top ${c.objective}).'),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () async {
                final ok = await confirm(context, 'Start next season?',
                    'Players age and develop, contracts expire and retirements happen.',
                    action: 'Continue');
                if (!ok) return;
                final r = game.startNextSeason();
                if (context.mounted) toast(context, r.message);
              },
              child: const Text('START NEXT SEASON'),
            ),
          ),
        ]),
      ),
    );
  }

  static String _ord(int n) {
    if (n % 100 >= 11 && n % 100 <= 13) return 'th';
    switch (n % 10) {
      case 1:
        return 'st';
      case 2:
        return 'nd';
      case 3:
        return 'rd';
      default:
        return 'th';
    }
  }

  void _menu(BuildContext context, GameController game) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.save_outlined),
            title: const Text('Save & return to menu'),
            subtitle: const Text('Progress is also saved automatically.'),
            onTap: () async {
              Navigator.pop(ctx);
              await game.exitToMenu();
            },
          ),
        ]),
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  final String label, value;
  const _Metric(this.label, this.value);
  @override
  Widget build(BuildContext context) => Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(fontSize: 10, color: Colors.white60)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        ]),
      );
}

class _Team extends StatelessWidget {
  final String name, initials;
  final int color;
  const _Team(this.name, this.initials, this.color);
  @override
  Widget build(BuildContext context) => SizedBox(
        width: 110,
        child: Column(children: [
          ClubCrest(initials, color, radius: 25),
          const SizedBox(height: 7),
          Text(name, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600)),
        ]),
      );
}

class _Tile extends StatelessWidget {
  final IconData icon;
  final String label, value;
  const _Tile(this.icon, this.label, this.value);
  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: AppTheme.green, size: 19),
                const SizedBox(height: 7),
                Text(value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                Text(label, style: const TextStyle(color: Colors.white54, fontSize: 11)),
              ]),
        ),
      );
}
