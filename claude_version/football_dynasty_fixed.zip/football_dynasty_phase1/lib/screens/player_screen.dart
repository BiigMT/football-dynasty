import 'package:flutter/material.dart';
import '../domain/economy.dart';
import '../domain/models.dart';
import '../state/game_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class PlayerScreen extends StatelessWidget {
  final String playerId;
  const PlayerScreen({super.key, required this.playerId});

  @override
  Widget build(BuildContext context) {
    final game = GameScope.of(context);
    final c = game.career!;
    final p = c.players[playerId];
    if (p == null) {
      return Scaffold(appBar: AppBar(), body: const Center(child: Text('Player no longer exists.')));
    }
    final mine = p.clubId == c.userClubId;
    final freeAgent = p.clubId == null;
    final clubName = freeAgent ? 'Free agent' : c.clubs[p.clubId!]!.name;

    return Scaffold(
      appBar: AppBar(title: Text(p.name)),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Row(children: [
          CircleAvatar(
            radius: 30,
            backgroundColor: AppTheme.panelLight,
            child: Text(p.position, style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(p.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              Text('$clubName • Age ${p.age}', style: const TextStyle(color: Colors.white60)),
            ]),
          ),
          RatingBadge(p.rating),
        ]),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              _row('Potential', c.potentialLabel(p)),
              _row('Market value', fmtMoney(p.value)),
              _row('Wage', fmtWage(p.wage)),
              _row('Contract', freeAgent ? 'None' : 'Until ${c.season + p.contractYears}'),
              _row('Fitness', '${p.fitness}%'),
              _row('Morale', '${p.morale}%'),
              _row('Appearances', '${p.appearances}'),
              _row('Goals', '${p.goals}'),
              if (p.injuredMatches > 0) _row('Injury', 'Out for ${p.injuredMatches} match(es)'),
              if (p.suspendedMatches > 0) _row('Suspension', '${p.suspendedMatches} match(es)'),
            ]),
          ),
        ),
        const SizedBox(height: 14),
        if (mine) ..._ownActions(context, game, p),
        if (!mine) ..._marketActions(context, game, p, freeAgent),
      ]),
    );
  }

  Widget _row(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(k, style: const TextStyle(color: Colors.white60)),
          Text(v, style: const TextStyle(fontWeight: FontWeight.w700)),
        ]),
      );

  List<Widget> _ownActions(BuildContext context, GameController game, Player p) {
    return [
      SizedBox(
        width: double.infinity,
        child: FilledButton(
          onPressed: () async {
            final wage = Economy.renewalWage(p);
            final years = Economy.renewalYears(p);
            final ok = await confirm(context, 'Renew contract?',
                '${p.name} asks for ${fmtWage(wage)} for $years years.',
                action: 'Offer');
            if (!ok) return;
            final r = game.renew(p.id);
            if (context.mounted) toast(context, r.message);
          },
          child: const Text('RENEW CONTRACT'),
        ),
      ),
      const SizedBox(height: 8),
      SizedBox(
        width: double.infinity,
        child: OutlinedButton(
          onPressed: () async {
            final cost = Economy.releaseCost(p);
            final ok = await confirm(context, 'Release ${p.name}?',
                'Compensation of ${fmtMoney(cost)} will be paid. This cannot be undone.',
                action: 'Release');
            if (!ok) return;
            final r = game.release(p.id);
            if (!context.mounted) return;
            toast(context, r.message);
            if (r.ok) Navigator.pop(context);
          },
          child: const Text('RELEASE PLAYER'),
        ),
      ),
    ];
  }

  List<Widget> _marketActions(
      BuildContext context, GameController game, Player p, bool freeAgent) {
    final c = game.career!;
    final shortlisted = c.shortlist.contains(p.id);
    return [
      if (freeAgent)
        SizedBox(
          width: double.infinity,
          child: FilledButton(
            onPressed: () async {
              final ok = await confirm(context, 'Sign ${p.name}?',
                  'Free transfer on ${fmtWage(Economy.wageFor(p))} for 2 years.',
                  action: 'Sign');
              if (!ok) return;
              final r = game.signFreeAgent(p.id);
              if (!context.mounted) return;
              toast(context, r.message);
              if (r.ok) Navigator.pop(context);
            },
            child: const Text('SIGN FREE AGENT'),
          ),
        )
      else
        SizedBox(
          width: double.infinity,
          child: FilledButton(
            onPressed: () => _bidDialog(context, game, p),
            child: Text(c.isWindowOpen ? 'MAKE BID' : 'TRANSFER WINDOW CLOSED'),
          ),
        ),
      const SizedBox(height: 8),
      SizedBox(
        width: double.infinity,
        child: OutlinedButton.icon(
          onPressed: () => game.toggleShortlist(p.id),
          icon: Icon(shortlisted ? Icons.bookmark : Icons.bookmark_border),
          label: Text(shortlisted ? 'REMOVE FROM SHORTLIST' : 'ADD TO SHORTLIST'),
        ),
      ),
    ];
  }

  Future<void> _bidDialog(BuildContext context, GameController game, Player p) async {
    final c = game.career!;
    if (!c.isWindowOpen) {
      toast(context, 'The transfer window is closed.');
      return;
    }
    final controller = TextEditingController(text: '${p.value}');
    final fee = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Bid for ${p.name}'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('Value ${fmtMoney(p.value)} • Budget ${fmtMoney(c.userClub.transferBudget)}',
              style: const TextStyle(color: Colors.white60, fontSize: 12)),
          const SizedBox(height: 12),
          TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Fee (€)', border: OutlineInputBorder()),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, int.tryParse(controller.text.trim())),
            child: const Text('Bid'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (fee == null || fee <= 0 || !context.mounted) return;
    final r = game.bid(p.id, fee);
    if (!context.mounted) return;
    switch (r.status) {
      case BidStatus.accepted:
        toast(context, '${p.name} joins for ${fmtMoney(fee)}.');
        Navigator.pop(context);
        break;
      case BidStatus.countered:
        final again = await confirm(context, 'Counter-offer',
            '${r.message} They will accept ${fmtMoney(r.counter!)}.',
            action: 'Pay ${fmtMoney(r.counter!)}');
        if (!again || !context.mounted) return;
        final r2 = game.bid(p.id, r.counter!);
        if (!context.mounted) return;
        toast(context, r2.status == BidStatus.accepted ? '${p.name} has signed.' : r2.message);
        if (r2.status == BidStatus.accepted) Navigator.pop(context);
        break;
      default:
        toast(context, r.message);
    }
  }
}
