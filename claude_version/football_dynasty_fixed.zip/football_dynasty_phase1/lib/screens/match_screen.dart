import 'dart:async';
import 'package:flutter/material.dart';
import '../domain/career.dart';
import '../domain/models.dart';
import '../state/game_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

/// Replays the events of an already-simulated match. The outcome is decided by
/// the engine; this screen only reveals it over time (a Flame pitch view can
/// consume the same event list later).
class MatchScreen extends StatefulWidget {
  final MatchResult result;
  const MatchScreen({super.key, required this.result});

  @override
  State<MatchScreen> createState() => _MatchScreenState();
}

class _MatchScreenState extends State<MatchScreen> {
  Timer? timer;
  int shown = 0; // number of events revealed
  bool fast = false;

  List<MatchEvent> get events => widget.result.events;
  bool get finished => shown >= events.length;

  @override
  void initState() {
    super.initState();
    _start();
  }

  void _start() {
    timer?.cancel();
    timer = Timer.periodic(Duration(milliseconds: fast ? 150 : 700), (_) {
      if (!mounted) return;
      if (finished) {
        timer?.cancel();
        return;
      }
      setState(() => shown++);
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = GameScope.of(context).career!;
    final r = widget.result;
    final home = c.clubs[r.homeId]!;
    final away = c.clubs[r.awayId]!;
    final visible = events.take(shown).toList();
    var hg = 0, ag = 0;
    for (final e in visible) {
      if (e.type == EventType.goal) {
        if (e.clubId == r.homeId) {
          hg++;
        } else {
          ag++;
        }
      }
    }
    final minute = visible.isEmpty ? 0 : visible.last.minute;

    return Scaffold(
      appBar: AppBar(title: const Text('Match centre')),
      body: Column(children: [
        Container(
          padding: const EdgeInsets.all(18),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            _side(home),
            Column(children: [
              Text('$hg - $ag', style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w800)),
              Text(finished ? 'FULL TIME' : "$minute'",
                  style: TextStyle(color: finished ? AppTheme.gold : AppTheme.green, fontWeight: FontWeight.bold)),
            ]),
            _side(away),
          ]),
        ),
        if (!finished)
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            TextButton(
              onPressed: () {
                setState(() => fast = !fast);
                _start();
              },
              child: Text(fast ? 'Normal speed' : 'Fast forward'),
            ),
            TextButton(
              onPressed: () {
                timer?.cancel();
                setState(() => shown = events.length);
              },
              child: const Text('Skip to end'),
            ),
          ]),
        Expanded(
          child: ListView(padding: const EdgeInsets.symmetric(horizontal: 18), children: [
            for (final e in visible.reversed) _eventTile(e, c),
            if (finished) _stats(r, home, away),
            const SizedBox(height: 20),
          ]),
        ),
        if (finished)
          Padding(
            padding: const EdgeInsets.all(18),
            child: SizedBox(
              width: double.infinity,
              child: FilledButton(onPressed: () => Navigator.pop(context), child: const Text('CONTINUE')),
            ),
          ),
      ]),
    );
  }

  Widget _side(Club club) => SizedBox(
        width: 100,
        child: Column(children: [
          ClubCrest(club.shortName, club.colorValue, radius: 26),
          const SizedBox(height: 6),
          Text(club.name, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
        ]),
      );

  Widget _eventTile(MatchEvent e, Career c) {
    IconData icon;
    Color color = Colors.white70;
    switch (e.type) {
      case EventType.goal:
        icon = Icons.sports_soccer;
        color = AppTheme.green;
        break;
      case EventType.yellow:
        icon = Icons.square;
        color = AppTheme.gold;
        break;
      case EventType.red:
        icon = Icons.square;
        color = Colors.redAccent;
        break;
      case EventType.injury:
        icon = Icons.healing;
        color = Colors.orangeAccent;
        break;
      case EventType.save:
        icon = Icons.back_hand_outlined;
        break;
      case EventType.shotOff:
        icon = Icons.call_made;
        break;
      default:
        icon = Icons.flag_outlined;
    }
    final text = e.playerName == null ? e.detail : '${e.playerName} ${e.detail}';
    final club = e.clubId == null ? '' : ' (${c.clubs[e.clubId]!.shortName})';
    return ListTile(
      dense: true,
      leading: SizedBox(
        width: 54,
        child: Row(children: [
          Text(e.minuteLabel, style: const TextStyle(color: Colors.white54, fontSize: 12)),
          const Spacer(),
          Icon(icon, color: color, size: 18),
        ]),
      ),
      title: Text('$text$club',
          style: TextStyle(
              fontWeight: e.type == EventType.goal ? FontWeight.bold : FontWeight.normal)),
    );
  }

  Widget _stats(MatchResult r, Club home, Club away) {
    final s = r.stats;
    Widget row(String label, int h, int a) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Row(children: [
            SizedBox(width: 40, child: Text('$h', style: const TextStyle(fontWeight: FontWeight.bold))),
            Expanded(child: Text(label, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60))),
            SizedBox(width: 40, child: Text('$a', textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.bold))),
          ]),
        );
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          row('Possession %', s.homePossession, 100 - s.homePossession),
          row('Shots', s.homeShots, s.awayShots),
          row('On target', s.homeOnTarget, s.awayOnTarget),
          row('Yellow cards', s.homeYellows, s.awayYellows),
          row('Red cards', s.homeReds, s.awayReds),
        ]),
      ),
    );
  }
}
