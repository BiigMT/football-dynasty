import 'package:flutter/material.dart';
import '../state/game_controller.dart';
import 'competitions_screen.dart';
import 'dashboard_screen.dart';
import 'squad_screen.dart';
import 'tactics_screen.dart';
import 'transfers_screen.dart';

class ShellScreen extends StatefulWidget {
  const ShellScreen({super.key});

  @override
  State<ShellScreen> createState() => _ShellScreenState();
}

class _ShellScreenState extends State<ShellScreen> {
  int selectedIndex = 0;

  static const pages = [
    DashboardScreen(),
    SquadScreen(),
    TransfersScreen(),
    CompetitionsScreen(),
    TacticsScreen(),
  ];

  static const destinations = [
    NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
    NavigationDestination(icon: Icon(Icons.groups_outlined), selectedIcon: Icon(Icons.groups), label: 'Squad'),
    NavigationDestination(icon: Icon(Icons.swap_horiz), label: 'Transfers'),
    NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events), label: 'League'),
    NavigationDestination(icon: Icon(Icons.sports_soccer_outlined), selectedIcon: Icon(Icons.sports_soccer), label: 'Tactics'),
  ];

  @override
  Widget build(BuildContext context) {
    // Subscribe so every tab refreshes when the career changes.
    GameScope.of(context);
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: selectedIndex, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        destinations: destinations,
        onDestinationSelected: (value) => setState(() => selectedIndex = value),
      ),
    );
  }
}
