import 'package:flutter/material.dart';
import '../domain/lineup.dart';
import '../domain/models.dart';
import '../state/game_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class TacticsScreen extends StatelessWidget {
  const TacticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final game = GameScope.of(context);
    final c = game.career!;
    final t = c.userClub.tactics;
    final squad = c.userSquad;
    final xi = LineupBuilder.build(squad, t);
    final slots = formations[t.formation]!;

    void update(void Function(Tactics) change) {
      final copy = t.copy();
      change(copy);
      game.setTactics(copy);
    }

    return ListView(padding: const EdgeInsets.all(18), children: [
      const ScreenHeader(kicker: 'MATCH PREPARATION', title: 'Tactics'),
      const SizedBox(height: 16),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Formation', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              for (final f in formations.keys)
                ChoiceChip(
                  label: Text(f),
                  selected: t.formation == f,
                  onSelected: (_) => update((n) {
                    n.formation = f;
                    n.lineup = List<String>.filled(11, '');
                  }),
                ),
            ]),
            const SizedBox(height: 16),
            _segment('Mentality', mentalityLabels, t.mentality, (v) => update((n) => n.mentality = v)),
            const SizedBox(height: 12),
            _segment('Pressing', pressingLabels, t.pressing, (v) => update((n) => n.pressing = v)),
            const SizedBox(height: 12),
            _segment('Tempo', tempoLabels, t.tempo, (v) => update((n) => n.tempo = v)),
            const SizedBox(height: 10),
            const Text(
                'Attacking and fast play create more chances but leave you open. High pressing wins the ball but tires players and risks cards.',
                style: TextStyle(color: Colors.white54, fontSize: 11)),
          ]),
        ),
      ),
      const SizedBox(height: 14),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('Starting XI', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        TextButton(
          onPressed: () => update((n) => n.lineup = List<String>.filled(11, '')),
          child: const Text('Auto-pick'),
        ),
      ]),
      Text('Team strength ${LineupBuilder.averageEffective(xi).toStringAsFixed(1)}',
          style: const TextStyle(color: AppTheme.green)),
      const SizedBox(height: 8),
      for (var i = 0; i < xi.length; i++)
        Card(
          margin: const EdgeInsets.only(bottom: 5),
          child: ListTile(
            dense: true,
            onTap: () => _pick(context, game, i, slots[i]),
            leading: CircleAvatar(
              radius: 18,
              backgroundColor: AppTheme.panelLight,
              child: Text(slots[i], style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
            ),
            title: Text(xi[i].player.name),
            subtitle: Text(
              '${xi[i].player.position} • Fit ${xi[i].player.fitness}%'
              '${xi[i].player.position != slots[i] ? ' • Out of position' : ''}'
              '${!xi[i].player.isAvailable ? ' • Unavailable' : ''}',
              style: TextStyle(
                  color: xi[i].player.position != slots[i] || !xi[i].player.isAvailable
                      ? Colors.orangeAccent
                      : Colors.white54,
                  fontSize: 11),
            ),
            trailing: RatingBadge(xi[i].player.rating),
          ),
        ),
      if (xi.length < 11)
        const Text('You do not have enough players to fill a full XI.',
            style: TextStyle(color: Colors.orangeAccent)),
    ]);
  }

  Widget _segment(String label, List<String> labels, int value, void Function(int) onChanged) =>
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        SizedBox(
          width: double.infinity,
          child: SegmentedButton<int>(
            segments: [for (var i = 0; i < labels.length; i++) ButtonSegment(value: i, label: Text(labels[i]))],
            selected: {value},
            onSelectionChanged: (s) => onChanged(s.first),
          ),
        ),
      ]);

  void _pick(BuildContext context, GameController game, int index, String slot) {
    final c = game.career!;
    final t = c.userClub.tactics;
    final candidates = c.userSquad
      ..sort((a, b) =>
          LineupSlot(slot, b).effective.compareTo(LineupSlot(slot, a).effective));
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.7,
          builder: (_, scroll) => ListView(controller: scroll, children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text('Choose $slot', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            for (final p in candidates)
              ListTile(
                enabled: p.isAvailable,
                title: Text(p.name),
                subtitle: Text(
                    '${p.position} • Fit ${p.fitness}%${p.injuredMatches > 0 ? ' • Injured' : ''}${p.suspendedMatches > 0 ? ' • Suspended' : ''}'),
                trailing: RatingBadge(p.rating),
                onTap: () {
                  final copy = t.copy();
                  // A player can only occupy one slot.
                  for (var i = 0; i < copy.lineup.length; i++) {
                    if (copy.lineup[i] == p.id) copy.lineup[i] = '';
                  }
                  copy.lineup[index] = p.id;
                  // Pin the other slots to the current auto-selection so the pick sticks.
                  final xi = LineupBuilder.build(c.userSquad, t);
                  for (var i = 0; i < xi.length; i++) {
                    if (i != index && copy.lineup[i].isEmpty && xi[i].player.id != p.id) {
                      copy.lineup[i] = xi[i].player.id;
                    }
                  }
                  game.setTactics(copy);
                  Navigator.pop(ctx);
                },
              ),
          ]),
        ),
      ),
    );
  }
}
