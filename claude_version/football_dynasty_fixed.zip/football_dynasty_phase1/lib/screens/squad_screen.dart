import 'package:flutter/material.dart';
import '../domain/models.dart';
import '../state/game_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import 'player_screen.dart';

class SquadScreen extends StatefulWidget {
  const SquadScreen({super.key});
  @override
  State<SquadScreen> createState() => _SquadScreenState();
}

class _SquadScreenState extends State<SquadScreen> {
  PositionGroup? filter;
  String sort = 'Rating';

  @override
  Widget build(BuildContext context) {
    final c = GameScope.of(context).career!;
    var players = c.userSquad.where((p) => filter == null || p.group == filter).toList();
    switch (sort) {
      case 'Age':
        players.sort((a, b) => a.age.compareTo(b.age));
        break;
      case 'Position':
        players.sort((a, b) => allPositions.indexOf(a.position).compareTo(allPositions.indexOf(b.position)));
        break;
      case 'Fitness':
        players.sort((a, b) => a.fitness.compareTo(b.fitness));
        break;
      default:
        players.sort((a, b) => b.rating.compareTo(a.rating));
    }

    return ListView(padding: const EdgeInsets.all(18), children: [
      const ScreenHeader(kicker: 'FIRST TEAM', title: 'Squad'),
      const SizedBox(height: 6),
      Text('${c.userSquad.length} registered players • ${fmtMoney(c.wageBill(c.userClubId))}/wk wages',
          style: const TextStyle(color: Colors.white60)),
      const SizedBox(height: 12),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(children: [
          _chip('All', filter == null, () => setState(() => filter = null)),
          _chip('GK', filter == PositionGroup.gk, () => setState(() => filter = PositionGroup.gk)),
          _chip('DEF', filter == PositionGroup.def, () => setState(() => filter = PositionGroup.def)),
          _chip('MID', filter == PositionGroup.mid, () => setState(() => filter = PositionGroup.mid)),
          _chip('ATT', filter == PositionGroup.att, () => setState(() => filter = PositionGroup.att)),
        ]),
      ),
      const SizedBox(height: 6),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(children: [
          const Padding(padding: EdgeInsets.only(right: 8), child: Text('Sort:', style: TextStyle(color: Colors.white54))),
          for (final s in ['Rating', 'Age', 'Position', 'Fitness'])
            _chip(s, sort == s, () => setState(() => sort = s)),
        ]),
      ),
      const SizedBox(height: 10),
      for (final p in players)
        Padding(
          padding: const EdgeInsets.only(bottom: 6),
          child: Card(
            child: ListTile(
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => PlayerScreen(playerId: p.id))),
              leading: CircleAvatar(
                backgroundColor: AppTheme.panelLight,
                child: Text(p.position,
                    style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
              ),
              title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(_subtitle(p)),
              trailing: RatingBadge(p.rating),
            ),
          ),
        ),
    ]);
  }

  String _subtitle(Player p) {
    final status = p.injuredMatches > 0
        ? '  •  Injured (${p.injuredMatches})'
        : (p.suspendedMatches > 0 ? '  •  Suspended' : '');
    final contract = p.contractYears <= 1 ? '  •  Contract ending' : '';
    return 'Age ${p.age}  •  Fit ${p.fitness}%$status$contract';
  }

  Widget _chip(String label, bool selected, VoidCallback onTap) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: ChoiceChip(label: Text(label), selected: selected, onSelected: (_) => onTap()),
      );
}
