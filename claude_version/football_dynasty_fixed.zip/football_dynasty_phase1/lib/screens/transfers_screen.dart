import 'package:flutter/material.dart';
import '../domain/models.dart';
import '../state/game_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import 'player_screen.dart';

class TransfersScreen extends StatefulWidget {
  const TransfersScreen({super.key});
  @override
  State<TransfersScreen> createState() => _TransfersScreenState();
}

class _TransfersScreenState extends State<TransfersScreen> {
  String query = '';
  PositionGroup? group;

  @override
  Widget build(BuildContext context) {
    final game = GameScope.of(context);
    final c = game.career!;
    final window = c.windowName;
    return DefaultTabController(
      length: 4,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const ScreenHeader(kicker: 'PLAYER MARKET', title: 'Transfers'),
            const SizedBox(height: 8),
            Text(window == null ? 'Transfer window closed' : '$window window • Open',
                style: TextStyle(color: window == null ? Colors.white54 : AppTheme.green)),
            Text('Budget ${fmtMoney(c.userClub.transferBudget)} • Wage room ${fmtMoney(c.userClub.wageBudget - c.wageBill(c.userClubId))}/wk',
                style: const TextStyle(color: Colors.white60, fontSize: 12)),
          ]),
        ),
        TabBar(tabs: [
          const Tab(text: 'Market'),
          const Tab(text: 'Free'),
          Tab(text: 'Offers${c.offers.isEmpty ? '' : ' (${c.offers.length})'}'),
          const Tab(text: 'Shortlist'),
        ]),
        Expanded(
          child: TabBarView(children: [
            _market(context, game),
            _list(context, c.freeAgents..sort((a, b) => b.rating.compareTo(a.rating)), game,
                empty: 'No free agents available.'),
            _offers(context, game),
            _list(context, c.shortlist.map((id) => c.players[id]).whereType<Player>().toList(), game,
                empty: 'Shortlist is empty. Open a player and tap "Add to shortlist".'),
          ]),
        ),
      ]),
    );
  }

  Widget _market(BuildContext context, GameController game) {
    final c = game.career!;
    var list = c.players.values
        .where((p) => p.clubId != null && p.clubId != c.userClubId)
        .where((p) => group == null || p.group == group)
        .where((p) => query.isEmpty || p.name.toLowerCase().contains(query.toLowerCase()))
        .toList()
      ..sort((a, b) => b.rating.compareTo(a.rating));
    list = list.take(60).toList();
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(18, 10, 18, 0),
        child: TextField(
          decoration: const InputDecoration(
              prefixIcon: Icon(Icons.search), hintText: 'Search by name', border: OutlineInputBorder()),
          onChanged: (v) => setState(() => query = v),
        ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 0),
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(children: [
            for (final e in {
              'All': null,
              'GK': PositionGroup.gk,
              'DEF': PositionGroup.def,
              'MID': PositionGroup.mid,
              'ATT': PositionGroup.att,
            }.entries)
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(e.key),
                  selected: group == e.value,
                  onSelected: (_) => setState(() => group = e.value),
                ),
              ),
          ]),
        ),
      ),
      Expanded(child: _list(context, list, game, empty: 'No players match your search.')),
    ]);
  }

  Widget _list(BuildContext context, List<Player> list, GameController game,
      {required String empty}) {
    final c = game.career!;
    if (list.isEmpty) {
      return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(empty, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54))));
    }
    return ListView(padding: const EdgeInsets.all(18), children: [
      for (final p in list)
        Padding(
          padding: const EdgeInsets.only(bottom: 6),
          child: Card(
            child: ListTile(
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => PlayerScreen(playerId: p.id))),
              leading: CircleAvatar(
                backgroundColor: AppTheme.panelLight,
                child: Text(p.position, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
              ),
              title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(
                  '${p.clubId == null ? 'Free agent' : c.clubs[p.clubId!]!.shortName} • Age ${p.age} • ${fmtMoney(p.value)}'),
              trailing: RatingBadge(p.rating),
            ),
          ),
        ),
    ]);
  }

  Widget _offers(BuildContext context, GameController game) {
    final c = game.career!;
    if (c.offers.isEmpty) {
      return const Center(
          child: Text('No incoming offers.', style: TextStyle(color: Colors.white54)));
    }
    return ListView(padding: const EdgeInsets.all(18), children: [
      for (final o in c.offers)
        Builder(builder: (context) {
          final p = c.players[o.playerId];
          final club = c.clubs[o.fromClubId]!;
          if (p == null) return const SizedBox.shrink();
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${club.name} want ${p.name}',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text('Offer ${fmtMoney(o.fee)} • Value ${fmtMoney(p.value)} • Expires after matchday ${o.expiresMatchday}',
                    style: const TextStyle(color: Colors.white60, fontSize: 12)),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(
                    child: FilledButton(
                      onPressed: () async {
                        final ok = await confirm(context, 'Sell ${p.name}?',
                            'Sell to ${club.name} for ${fmtMoney(o.fee)}. This cannot be undone.',
                            action: 'Sell');
                        if (!ok) return;
                        final r = game.acceptOffer(o.id);
                        if (context.mounted) toast(context, r.message);
                      },
                      child: const Text('Accept'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => game.rejectOffer(o.id),
                      child: const Text('Reject'),
                    ),
                  ),
                ]),
              ]),
            ),
          );
        }),
    ]);
  }
}
