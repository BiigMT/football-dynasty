import 'package:flutter/material.dart';
import '../domain/career.dart';
import '../domain/league.dart' as lg;
import '../state/game_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class CompetitionsScreen extends StatefulWidget {
  const CompetitionsScreen({super.key});
  @override
  State<CompetitionsScreen> createState() => _CompetitionsScreenState();
}

class _CompetitionsScreenState extends State<CompetitionsScreen> {
  int? viewMatchday;

  @override
  Widget build(BuildContext context) {
    final c = GameScope.of(context).career!;
    return DefaultTabController(
      length: 4,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 8),
          child: ScreenHeader(kicker: 'FICTIONAL LEAGUE', title: 'Premier Division ${c.seasonLabel}'),
        ),
        const TabBar(tabs: [
          Tab(text: 'Table'),
          Tab(text: 'Fixtures'),
          Tab(text: 'Scorers'),
          Tab(text: 'History'),
        ]),
        Expanded(
          child: TabBarView(children: [
            _table(c),
            _fixtures(c),
            _scorers(c),
            _history(c),
          ]),
        ),
      ]),
    );
  }

  Widget _table(Career c) {
    final rows = c.table;
    TextStyle head() => const TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.bold);
    Widget cell(String t, {double w = 28, bool bold = false}) => SizedBox(
        width: w,
        child: Text(t, textAlign: TextAlign.center, style: TextStyle(fontWeight: bold ? FontWeight.bold : null, fontSize: 13)));
    return ListView(padding: const EdgeInsets.all(12), children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        child: Row(children: [
          SizedBox(width: 26, child: Text('#', style: head())),
          Expanded(child: Text('CLUB', style: head())),
          for (final h in ['P', 'W', 'D', 'L']) SizedBox(width: 24, child: Text(h, textAlign: TextAlign.center, style: head())),
          SizedBox(width: 32, child: Text('GD', textAlign: TextAlign.center, style: head())),
          SizedBox(width: 32, child: Text('PTS', textAlign: TextAlign.center, style: head())),
        ]),
      ),
      for (var i = 0; i < rows.length; i++)
        Container(
          margin: const EdgeInsets.only(bottom: 3),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9),
          decoration: BoxDecoration(
            color: rows[i].clubId == c.userClubId ? AppTheme.green.withValues(alpha: .14) : AppTheme.panel,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(children: [
            SizedBox(width: 26, child: Text('${i + 1}', style: const TextStyle(fontSize: 13))),
            Expanded(child: Text(c.clubs[rows[i].clubId]!.name, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600))),
            cell('${rows[i].played}', w: 24),
            cell('${rows[i].won}', w: 24),
            cell('${rows[i].drawn}', w: 24),
            cell('${rows[i].lost}', w: 24),
            cell('${rows[i].goalDifference}', w: 32),
            cell('${rows[i].points}', w: 32, bold: true),
          ]),
        ),
    ]);
  }

  Widget _fixtures(Career c) {
    final md = viewMatchday ?? (c.seasonComplete ? c.totalMatchdays : c.matchday);
    final list = c.fixturesForMatchday(md);
    return ListView(padding: const EdgeInsets.all(18), children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        IconButton(
          onPressed: md > 1 ? () => setState(() => viewMatchday = md - 1) : null,
          icon: const Icon(Icons.chevron_left),
        ),
        Text('Matchday $md', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        IconButton(
          onPressed: md < c.totalMatchdays ? () => setState(() => viewMatchday = md + 1) : null,
          icon: const Icon(Icons.chevron_right),
        ),
      ]),
      for (final f in list)
        Card(
          color: f.involves(c.userClubId) ? AppTheme.panelLight : null,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(children: [
              Expanded(child: Text(c.clubs[f.homeId]!.name, textAlign: TextAlign.right, overflow: TextOverflow.ellipsis)),
              Container(
                width: 64,
                alignment: Alignment.center,
                child: Text(f.played ? '${f.homeGoals} - ${f.awayGoals}' : 'v',
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              ),
              Expanded(child: Text(c.clubs[f.awayId]!.name, overflow: TextOverflow.ellipsis)),
            ]),
          ),
        ),
    ]);
  }

  Widget _scorers(Career c) {
    final rows = lg.League.topScorers(c.fixtures, c.season);
    if (rows.isEmpty) {
      return const Center(child: Text('No goals scored yet.', style: TextStyle(color: Colors.white54)));
    }
    return ListView(padding: const EdgeInsets.all(18), children: [
      for (var i = 0; i < rows.length; i++)
        Builder(builder: (context) {
          final p = c.players[rows[i].playerId];
          if (p == null) return const SizedBox.shrink();
          final club = p.clubId == null ? 'Free agent' : c.clubs[p.clubId!]!.name;
          return Card(
            child: ListTile(
              leading: Text('${i + 1}', style: const TextStyle(fontWeight: FontWeight.bold)),
              title: Text(p.name),
              subtitle: Text('$club • ${p.position}'),
              trailing: Text('${rows[i].goals}', style: const TextStyle(color: AppTheme.green, fontWeight: FontWeight.bold, fontSize: 18)),
            ),
          );
        }),
    ]);
  }

  Widget _history(Career c) {
    if (c.history.isEmpty) {
      return const Center(child: Text('No completed seasons yet.', style: TextStyle(color: Colors.white54)));
    }
    return ListView(padding: const EdgeInsets.all(18), children: [
      for (final h in c.history.reversed)
        Card(
          child: ListTile(
            leading: const Icon(Icons.emoji_events_outlined, color: AppTheme.gold),
            title: Text('${h.season}/${(h.season + 1).toString().substring(2)}'),
            subtitle: Text('Champions: ${c.clubs[h.championId]!.name}'),
            trailing: Text('You: ${h.userPosition}  •  ${h.userPoints} pts'),
          ),
        ),
    ]);
  }
}
