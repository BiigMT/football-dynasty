-- Football Dynasty initial PostgreSQL schema.
-- Apply only after reviewing provider licensing, privacy and RLS policies.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Manager',
  created_at timestamptz not null default now()
);

create table if not exists public.data_sources (
  id uuid primary key default gen_random_uuid(),
  provider_key text not null unique,
  provider_name text not null,
  terms_url text,
  attribution_text text,
  license_notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.countries (
  id uuid primary key default gen_random_uuid(),
  iso_code char(2) unique,
  name text not null
);

create table if not exists public.competitions (
  id uuid primary key default gen_random_uuid(),
  source_id uuid references public.data_sources(id),
  source_competition_id text,
  name text not null,
  competition_type text not null check (competition_type in ('league','cup','international')),
  country_id uuid references public.countries(id),
  gender text not null default 'men' check (gender in ('men','women','mixed')),
  is_active boolean not null default true,
  unique(source_id, source_competition_id)
);

create table if not exists public.seasons (
  id uuid primary key default gen_random_uuid(),
  competition_id uuid not null references public.competitions(id) on delete cascade,
  name text not null,
  start_date date,
  end_date date,
  status text not null default 'scheduled' check (status in ('scheduled','active','completed')),
  unique(competition_id, name)
);

create table if not exists public.clubs (
  id uuid primary key default gen_random_uuid(),
  source_id uuid references public.data_sources(id),
  source_club_id text,
  name text not null,
  short_name text,
  country_id uuid references public.countries(id),
  founded_year integer,
  venue_name text,
  crest_asset_key text,
  data_updated_at timestamptz,
  unique(source_id, source_club_id)
);

create table if not exists public.players (
  id uuid primary key default gen_random_uuid(),
  source_id uuid references public.data_sources(id),
  source_player_id text,
  full_name text not null,
  date_of_birth date,
  country_id uuid references public.countries(id),
  preferred_foot text check (preferred_foot in ('left','right','both')),
  primary_position text,
  image_asset_key text,
  data_updated_at timestamptz,
  unique(source_id, source_player_id)
);

create table if not exists public.player_attributes (
  player_id uuid primary key references public.players(id) on delete cascade,
  pace smallint check (pace between 1 and 100),
  shooting smallint check (shooting between 1 and 100),
  passing smallint check (passing between 1 and 100),
  dribbling smallint check (dribbling between 1 and 100),
  defending smallint check (defending between 1 and 100),
  physical smallint check (physical between 1 and 100),
  goalkeeping smallint check (goalkeeping between 1 and 100),
  overall_rating smallint check (overall_rating between 1 and 100),
  potential_rating smallint check (potential_rating between 1 and 100),
  updated_at timestamptz not null default now()
);

create table if not exists public.season_clubs (
  season_id uuid not null references public.seasons(id) on delete cascade,
  club_id uuid not null references public.clubs(id),
  primary key(season_id, club_id)
);

create table if not exists public.player_registrations (
  id uuid primary key default gen_random_uuid(),
  player_id uuid not null references public.players(id),
  club_id uuid not null references public.clubs(id),
  season_id uuid references public.seasons(id),
  shirt_number smallint,
  valid_from date,
  valid_to date,
  registration_status text not null default 'registered'
    check (registration_status in ('registered','loaned','released','suspended')),
  source_id uuid references public.data_sources(id)
);

create table if not exists public.fixtures (
  id uuid primary key default gen_random_uuid(),
  season_id uuid not null references public.seasons(id) on delete cascade,
  home_club_id uuid not null references public.clubs(id),
  away_club_id uuid not null references public.clubs(id),
  kickoff_at timestamptz,
  venue text,
  status text not null default 'scheduled'
    check (status in ('scheduled','live','completed','postponed','cancelled')),
  home_score smallint,
  away_score smallint,
  source_fixture_id text,
  source_id uuid references public.data_sources(id),
  check (home_club_id <> away_club_id)
);

create table if not exists public.match_events (
  id uuid primary key default gen_random_uuid(),
  fixture_id uuid not null references public.fixtures(id) on delete cascade,
  minute smallint not null check (minute between 0 and 130),
  added_time smallint not null default 0,
  event_type text not null check (event_type in
    ('goal','own_goal','yellow_card','red_card','substitution','penalty_missed','injury','var')),
  club_id uuid references public.clubs(id),
  player_id uuid references public.players(id),
  related_player_id uuid references public.players(id),
  description text,
  sequence_number integer not null default 0
);

-- User-owned career saves are separate from shared reference football data.
create table if not exists public.career_saves (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  save_name text not null,
  game_version text not null,
  season_number integer not null default 1,
  current_date date,
  manager_name text,
  club_id uuid references public.clubs(id),
  local_revision bigint not null default 0,
  updated_at timestamptz not null default now()
);

create table if not exists public.sync_outbox (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  entity_type text not null,
  entity_id uuid not null,
  operation text not null check (operation in ('insert','update','delete')),
  payload jsonb not null,
  created_at timestamptz not null default now(),
  synced_at timestamptz,
  retry_count integer not null default 0
);

create index if not exists idx_fixtures_season_kickoff
  on public.fixtures(season_id, kickoff_at);
create index if not exists idx_registrations_player
  on public.player_registrations(player_id);
create index if not exists idx_match_events_fixture_minute
  on public.match_events(fixture_id, minute, sequence_number);
create index if not exists idx_career_saves_user_updated
  on public.career_saves(user_id, updated_at desc);
create index if not exists idx_sync_outbox_pending
  on public.sync_outbox(user_id, created_at) where synced_at is null;

-- RLS: user-owned records are private. Reference football data is readable by clients.
alter table public.profiles enable row level security;
alter table public.career_saves enable row level security;
alter table public.sync_outbox enable row level security;

alter table public.countries enable row level security;
alter table public.data_sources enable row level security;
alter table public.competitions enable row level security;
alter table public.seasons enable row level security;
alter table public.clubs enable row level security;
alter table public.players enable row level security;
alter table public.player_attributes enable row level security;
alter table public.season_clubs enable row level security;
alter table public.player_registrations enable row level security;
alter table public.fixtures enable row level security;
alter table public.match_events enable row level security;

create policy "profile owner can read" on public.profiles
  for select using (auth.uid() = id);
create policy "profile owner can update" on public.profiles
  for update using (auth.uid() = id) with check (auth.uid() = id);

create policy "owner manages career saves" on public.career_saves
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "owner manages sync outbox" on public.sync_outbox
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Shared reference data is readable by authenticated users.
create policy "authenticated read countries" on public.countries
  for select to authenticated using (true);
create policy "authenticated read sources" on public.data_sources
  for select to authenticated using (true);
create policy "authenticated read competitions" on public.competitions
  for select to authenticated using (true);
create policy "authenticated read seasons" on public.seasons
  for select to authenticated using (true);
create policy "authenticated read clubs" on public.clubs
  for select to authenticated using (true);
create policy "authenticated read players" on public.players
  for select to authenticated using (true);
create policy "authenticated read attributes" on public.player_attributes
  for select to authenticated using (true);
create policy "authenticated read season clubs" on public.season_clubs
  for select to authenticated using (true);
create policy "authenticated read registrations" on public.player_registrations
  for select to authenticated using (true);
create policy "authenticated read fixtures" on public.fixtures
  for select to authenticated using (true);
create policy "authenticated read events" on public.match_events
  for select to authenticated using (true);

-- No client-side write policies are granted for provider reference data.
-- Populate/update those tables from a trusted server-side import process only.
