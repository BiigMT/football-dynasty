import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:football_dynasty/data/save_store.dart';
import 'package:football_dynasty/domain/career.dart';
import 'package:football_dynasty/domain/economy.dart';
import 'package:football_dynasty/domain/models.dart';

Career _new([int seed = 12345]) =>
    Career.newGame(managerName: 'Tester', userClubId: 'c01', seed: seed);

void main() {
  test('new game builds a consistent world', () {
    final c = _new();
    expect(c.clubs.length, 16);
    expect(c.totalMatchdays, 30);
    expect(c.fixtures.length, 16 * 15);
    for (final club in c.clubs.values) {
      expect(c.squad(club.id).length, 24);
      expect(c.squad(club.id).where((p) => p.position == 'GK').length, 3);
    }
    expect(c.freeAgents.isNotEmpty, isTrue);
    expect(c.userClub.wageBudget > c.wageBill('c01'), isTrue);
  });

  test('world generation is deterministic', () {
    expect(jsonEncode(_new(7).toJson()), jsonEncode(_new(7).toJson()));
    expect(jsonEncode(_new(7).toJson()) == jsonEncode(_new(8).toJson()), isFalse);
  });

  test('a full season plays out with a consistent table', () {
    final c = _new();
    var userMatches = 0;
    while (!c.seasonComplete) {
      final r = c.playMatchday();
      expect(r, isNotNull);
      userMatches++;
    }
    expect(userMatches, 30);
    expect(c.fixtures.every((f) => f.played), isTrue);
    final table = c.table;
    expect(table.every((r) => r.played == 30), isTrue);
    final gf = table.fold<int>(0, (a, r) => a + r.goalsFor);
    final ga = table.fold<int>(0, (a, r) => a + r.goalsAgainst);
    expect(gf, ga);
    final pts = table.fold<int>(0, (a, r) => a + r.points);
    final draws = c.fixtures.where((f) => f.homeGoals == f.awayGoals).length;
    expect(pts, c.fixtures.length * 3 - draws);
    // Average goals per game should be plausible.
    expect(gf / c.fixtures.length > 1.8 && gf / c.fixtures.length < 3.5, isTrue);
  });

  test('same seed and actions give identical careers', () {
    final a = _new(99), b = _new(99);
    a.simulateToSeasonEnd();
    b.simulateToSeasonEnd();
    expect(jsonEncode(a.toJson()), jsonEncode(b.toJson()));
  });

  test('save round-trips through JSON mid-season', () async {
    final c = _new();
    for (var i = 0; i < 5; i++) {
      c.playMatchday();
    }
    final store = MemorySaveStore();
    await store.save(1, c);
    final loaded = (await store.load(1))!;
    expect(jsonEncode(loaded.toJson()), jsonEncode(c.toJson()));
    // The loaded career keeps playing identically.
    c.playMatchday();
    loaded.playMatchday();
    expect(jsonEncode(loaded.toJson()), jsonEncode(c.toJson()));
  });

  test('season rollover ages players and builds new fixtures', () {
    final c = _new();
    c.simulateToSeasonEnd();
    final agesBefore = {for (final p in c.players.values) p.id: p.age};
    final r = c.startNextSeason();
    expect(r.ok, isTrue);
    expect(c.season, Career.startSeason + 1);
    expect(c.matchday, 1);
    expect(c.history.length, 1);
    for (final p in c.players.values) {
      final before = agesBefore[p.id];
      if (before != null) expect(p.age, before + 1);
    }
    for (final club in c.clubs.values) {
      if (club.id != c.userClubId) {
        expect(c.squad(club.id).length >= 24, isTrue);
      }
    }
    expect(c.userSquad.length >= 16, isTrue);
    expect(c.fixturesForMatchday(1).length, 8);
    // A second season can be played.
    c.simulateToSeasonEnd();
    expect(c.seasonComplete, isTrue);
  });

  test('cannot start next season early', () {
    expect(_new().startNextSeason().ok, isFalse);
  });

  group('transfers', () {
    test('window is open at the start and closed mid-season', () {
      final c = _new();
      expect(c.isWindowOpen, isTrue);
      for (var i = 0; i < 6; i++) {
        c.playMatchday();
      }
      expect(c.isWindowOpen, isFalse);
      final target = c.players.values.firstWhere((p) => p.clubId != null && p.clubId != 'c01');
      expect(c.bid(target.id, 1000000).status, BidStatus.blocked);
    });

    test('a high bid is accepted and money moves', () {
      final c = _new();
      c.userClub.transferBudget = 200000000;
      c.userClub.balance = 200000000;
      c.userClub.wageBudget = 10000000;
      final target = c.players.values.firstWhere(
          (p) => p.clubId == 'c05' && p.position == 'ST' && p.id.isNotEmpty);
      final fee = Economy.askingPrice(target, c.squad('c05'));
      final before = c.userSquad.length;
      final r = c.bid(target.id, fee);
      expect(r.status, BidStatus.accepted);
      expect(target.clubId, 'c01');
      expect(c.userSquad.length, before + 1);
      expect(c.userClub.transferBudget, 200000000 - fee);
      expect(c.squad('c05').length >= 24, isTrue, reason: 'AI club refills its squad');
    });

    test('a lowball bid is rejected and cannot exceed budget', () {
      final c = _new();
      c.userClub.transferBudget = 50000000;
      c.userClub.balance = 50000000;
      c.userClub.wageBudget = 10000000;
      final target = c.players.values.firstWhere((p) => p.clubId == 'c04');
      expect(c.bid(target.id, 10000).status, BidStatus.rejected);
      expect(c.bid(target.id, 999000000).status, BidStatus.blocked);
    });

    test('release enforces minimum squad size and charges compensation', () {
      final c = _new();
      c.userClub.balance = 100000000;
      final p = c.userSquad.first;
      final cost = Economy.releaseCost(p);
      final bal = c.userClub.balance;
      expect(c.releasePlayer(p.id).ok, isTrue);
      expect(c.userClub.balance, bal - cost);
      expect(p.clubId, isNull);
      while (c.userSquad.length > Economy.minSquad) {
        expect(c.releasePlayer(c.userSquad.last.id).ok, isTrue);
      }
      expect(c.releasePlayer(c.userSquad.last.id).ok, isFalse);
    });

    test('free agents can be signed', () {
      final c = _new();
      c.userClub.wageBudget = 10000000;
      final fa = c.freeAgents.firstWhere((p) => Economy.freeAgentWilling(p, c.userClub));
      expect(c.signFreeAgent(fa.id).ok, isTrue);
      expect(fa.clubId, 'c01');
    });

    test('incoming offers can be accepted', () {
      final c = _new();
      var guard = 0;
      while (c.offers.isEmpty && !c.seasonComplete && guard++ < 40) {
        c.playMatchday();
        if (!c.isWindowOpen && c.matchday < 16) {
          // jump ahead through the closed period quickly
          while (c.matchday < 16) {
            c.playMatchday();
          }
        }
      }
      if (c.offers.isNotEmpty) {
        final o = c.offers.first;
        final budget = c.userClub.transferBudget;
        expect(c.acceptOffer(o.id).ok, isTrue);
        expect(c.userClub.transferBudget, budget + o.fee);
        expect(c.players[o.playerId]!.clubId, o.fromClubId);
      }
    });
  });

  test('suspensions and injuries are served over time', () {
    final c = _new();
    final p = c.userSquad.first;
    p.injuredMatches = 2;
    p.suspendedMatches = 1;
    c.playMatchday();
    expect(p.injuredMatches, 1);
    expect(p.suspendedMatches, 0);
  });
}
