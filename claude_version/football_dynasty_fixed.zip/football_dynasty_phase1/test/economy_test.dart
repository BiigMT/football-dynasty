import 'package:flutter_test/flutter_test.dart';
import 'package:football_dynasty/domain/economy.dart';
import 'package:football_dynasty/domain/models.dart';
import 'package:football_dynasty/domain/progression.dart';
import 'package:football_dynasty/domain/rng.dart';

Player _p(int rating, int age, {int potential = 0}) => Player(
      id: 'x',
      name: 'X',
      position: 'ST',
      age: age,
      rating: rating,
      potential: potential == 0 ? rating : potential,
      wage: 1000,
      contractYears: 3,
    );

void main() {
  test('value rises with rating and falls with age', () {
    expect(Economy.value(_p(80, 26)) > Economy.value(_p(70, 26)), isTrue);
    expect(Economy.value(_p(75, 33)) < Economy.value(_p(75, 26)), isTrue);
    expect(Economy.value(_p(60, 19, potential: 80)) > Economy.value(_p(60, 27)), isTrue);
  });

  test('wages scale with rating', () {
    expect(Economy.wageFor(_p(80, 25)) > Economy.wageFor(_p(60, 25)), isTrue);
  });

  test('young players improve and old players decline', () {
    final rng = SeededRandom(1);
    final young = _p(60, 18, potential: 85);
    Progression.ageOneYear(young, rng);
    expect(young.rating > 60, isTrue);
    final old = _p(75, 34);
    Progression.ageOneYear(old, rng);
    expect(old.rating < 75, isTrue);
  });

  test('bid evaluation accepts, counters and rejects', () {
    final squad = List.generate(
        24, (i) => Player(id: 'p$i', name: 'n', position: 'CM', age: 25, rating: 60 + i % 10, potential: 65, wage: 1000, contractYears: 3));
    final target = squad.first;
    final ask = Economy.askingPrice(target, squad);
    expect(Economy.evaluateBid(player: target, fee: ask, sellerSquad: squad).status, BidStatus.accepted);
    expect(Economy.evaluateBid(player: target, fee: (ask * 0.9).round(), sellerSquad: squad).status, BidStatus.countered);
    expect(Economy.evaluateBid(player: target, fee: (ask * 0.3).round(), sellerSquad: squad).status, BidStatus.rejected);
    expect(Economy.evaluateBid(player: target, fee: ask, sellerSquad: squad.take(16).toList()).status, BidStatus.blocked);
  });
}
