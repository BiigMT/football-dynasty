import 'package:flutter_test/flutter_test.dart';
import 'package:football_dynasty/domain/fixtures.dart';
import 'package:football_dynasty/domain/lineup.dart';
import 'package:football_dynasty/domain/match_engine.dart';
import 'package:football_dynasty/domain/models.dart';
import 'package:football_dynasty/domain/rng.dart';
import 'package:football_dynasty/domain/world_generator.dart';

TeamSheet _team(String id, int level, int seedBase) {
  final rng = SeededRandom(seedBase);
  final club = Club(
    id: id,
    name: id,
    shortName: id,
    reputation: level,
    balance: 0,
    transferBudget: 0,
    wageBudget: 0,
    stadiumCapacity: 10000,
    colorValue: 0xFF000000,
  );
  final squad = <Player>[];
  var n = seedBase * 100;
  WorldGenerator.squadTemplate.forEach((pos, count) {
    for (var i = 0; i < count; i++) {
      squad.add(WorldGenerator.generatePlayer(
          rng: rng, number: n++, position: pos, level: level, clubId: id, fixedAge: 25));
    }
  });
  final tactics = Tactics();
  return TeamSheet(club, LineupBuilder.build(squad, tactics), tactics);
}

void main() {
  group('SeededRandom', () {
    test('same seed gives same sequence', () {
      final a = SeededRandom(42), b = SeededRandom(42);
      for (var i = 0; i < 100; i++) {
        expect(a.nextDouble(), b.nextDouble());
      }
    });

    test('values stay in range', () {
      final r = SeededRandom(7);
      for (var i = 0; i < 1000; i++) {
        final d = r.nextDouble();
        expect(d >= 0 && d < 1, isTrue);
        final n = r.range(3, 6);
        expect(n >= 3 && n <= 6, isTrue);
      }
    });
  });

  group('FixtureGenerator', () {
    test('double round robin is complete and balanced', () {
      final ids = List.generate(16, (i) => 'c$i');
      final rounds = FixtureGenerator.doubleRoundRobin(ids, 5);
      expect(rounds.length, 30);
      final seen = <String>{};
      for (final round in rounds) {
        final inRound = <String>{};
        for (final p in round) {
          expect(inRound.add(p.home), isTrue, reason: 'team plays twice in a round');
          expect(inRound.add(p.away), isTrue, reason: 'team plays twice in a round');
          expect(p.home != p.away, isTrue);
          expect(seen.add('${p.home}>${p.away}'), isTrue, reason: 'duplicate fixture');
        }
        expect(inRound.length, 16);
      }
      expect(seen.length, 16 * 15);
    });

    test('no team has a long home or away streak', () {
      final ids = List.generate(16, (i) => 'c$i');
      final rounds = FixtureGenerator.doubleRoundRobin(ids, 11);
      final seq = <String, List<bool>>{};
      for (final round in rounds) {
        for (final p in round) {
          seq.putIfAbsent(p.home, () => []).add(true);
          seq.putIfAbsent(p.away, () => []).add(false);
        }
      }
      for (final s in seq.values) {
        var run = 1, worst = 1;
        for (var i = 1; i < s.length; i++) {
          run = s[i] == s[i - 1] ? run + 1 : 1;
          if (run > worst) worst = run;
        }
        expect(worst <= 3, isTrue);
      }
    });
  });

  group('MatchEngine', () {
    test('same seed reproduces the same match', () {
      final h = _team('H', 70, 1), a = _team('A', 70, 2);
      final r1 = MatchEngine.simulate(fixtureId: 'f', home: h, away: a, seed: 99);
      final r2 = MatchEngine.simulate(fixtureId: 'f', home: h, away: a, seed: 99);
      expect(r1.toJson(), r2.toJson());
    });

    test('events are chronological and score matches goal events', () {
      final h = _team('H', 70, 1), a = _team('A', 70, 2);
      for (var s = 0; s < 50; s++) {
        final r = MatchEngine.simulate(fixtureId: 'f', home: h, away: a, seed: s);
        for (var i = 1; i < r.events.length; i++) {
          expect(r.events[i].minute >= r.events[i - 1].minute, isTrue);
        }
        final goals = r.events.where((e) => e.type == EventType.goal);
        expect(goals.length, r.homeGoals + r.awayGoals);
        expect(r.events.first.type, EventType.kickoff);
        expect(r.events.last.type, EventType.fulltime);
      }
    });

    test('equal teams score a realistic number of goals', () {
      final h = _team('H', 70, 1), a = _team('A', 70, 2);
      var goals = 0;
      const n = 400;
      for (var s = 0; s < n; s++) {
        final r = MatchEngine.simulate(fixtureId: 'f', home: h, away: a, seed: s * 31 + 1);
        goals += r.homeGoals + r.awayGoals;
      }
      final avg = goals / n;
      expect(avg > 1.8 && avg < 3.4, isTrue, reason: 'average goals was $avg');
    });

    test('stronger team wins clearly more often', () {
      final strong = _team('S', 80, 3), weak = _team('W', 62, 4);
      var strongWins = 0, weakWins = 0;
      for (var s = 0; s < 300; s++) {
        final r = MatchEngine.simulate(fixtureId: 'f', home: strong, away: weak, seed: s * 17 + 5);
        if (r.homeGoals > r.awayGoals) strongWins++;
        if (r.homeGoals < r.awayGoals) weakWins++;
      }
      expect(strongWins > weakWins * 3, isTrue, reason: '$strongWins vs $weakWins');
    });
  });
}
