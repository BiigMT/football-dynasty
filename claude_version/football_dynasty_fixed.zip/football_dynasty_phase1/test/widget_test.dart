import 'package:flutter_test/flutter_test.dart';
import 'package:football_dynasty/app.dart';
import 'package:football_dynasty/data/save_store.dart';

void main() {
  testWidgets('shows the save-slot menu when no career exists', (tester) async {
    await tester.pumpWidget(FootballDynastyApp(store: MemorySaveStore()));
    await tester.pumpAndSettle();
    expect(find.text('Career saves'), findsOneWidget);
    expect(find.text('New career'), findsWidgets);
  });
}
