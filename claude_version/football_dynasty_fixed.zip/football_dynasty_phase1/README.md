# Football Dynasty

An Android-first, offline-first football management game built with Flutter.
You pick a club, set tactics and lineups, play a 30-matchday season, trade players,
and carry your career across seasons. All clubs and players are **fictional generated data**.

## Run
```bash
flutter create . --platforms=android   # generates android/ (keeps existing lib/ and pubspec.yaml)
flutter pub get
flutter test                           # domain, engine and widget tests
flutter run
```
Requires a recent Flutter stable (3.27 or newer; the theme uses `CardThemeData` and `Color.withValues`).
After `flutter create`, check `git diff` to confirm it did not replace `lib/main.dart` or `pubspec.yaml`.

## What is implemented
- **Career and saves**: three save slots stored as JSON in the app documents directory,
  written atomically (temp file + rename), autosaved after every action.
- **World**: 16 fictional clubs, 24-player squads, free-agent pool, generated from a seed.
- **Season loop**: double round-robin fixtures (30 matchdays), league table with tie-breaks,
  top scorers, season history, end-of-season ageing/development/retirements/contract expiry.
- **Match engine**: deterministic, seeded, minute-by-minute simulation producing a time-ordered
  event list (goals, shots, saves, cards, injuries). Formation, mentality, pressing, tempo,
  fitness, morale, out-of-position penalties and red cards all affect results.
- **Match centre**: replays the engine's events with live score, stats and skip/fast-forward.
- **Squad**: filters, sorting, player profiles, contract renewal, release with compensation.
- **Tactics**: four formations, manual or automatic starting XI, persisted between sessions.
- **Transfers**: summer and winter windows, market search, bids with accept/counter/reject,
  free-agent signings, incoming offers for your players, shortlist, wage and budget limits.
- **Finances and board**: gate and TV income, wage bill, prize money, season objective and trust.
- **Tests**: RNG, fixtures, engine statistics, full seasons, save round-trips, transfers, economy.

## Not implemented (see docs/ARCHITECTURE.md)
- Supabase auth/sync: the schema in `supabase/migrations` is a draft and nothing in the app calls it.
  It needs a Supabase project and credentials, and the outbox/conflict rules are still to be written.
- Licensed real-world data: `FootballDataProvider` is the integration point; only a fictional
  `DemoDataProvider` exists. See docs/DATA_AND_LICENSING.md before importing anything real.
- Flame animated match view: the match centre is an event timeline. The engine already
  emits the events a Flame scene would consume.
- Cups, continental competitions, promotion/relegation, in-match substitutions and tactical changes,
  scouting, staff, training and facilities.

## Project structure
```text
lib/
  main.dart, app.dart
  domain/        pure Dart rules (no Flutter): models, rng, match_engine, lineup, fixtures,
                 league, economy, progression, world_generator, career
  data/          save_store (file + memory), football_data_provider (adapter contract)
  state/         game_controller (ChangeNotifier + InheritedNotifier scope)
  screens/       start, shell, dashboard, squad, player, transfers, competitions, tactics, match
  widgets/       shared UI helpers
  theme/         app_theme
test/            engine, career/transfers, economy, widget smoke test
supabase/        draft cloud schema (unused by the app yet)
docs/            ARCHITECTURE, INTERFACES, DATA_AND_LICENSING, GAME_RULES
```

## Data and licensing
Do not scrape websites or redistribute proprietary player/club datasets, crests, photographs,
kits or competition branding without permission. Keep provider attribution, source IDs,
timestamps and licensing metadata with imported records.
