# Game rules and tuning

All numbers live in `lib/domain`. Change them there and re-run `flutter test`.

## Season
- 16 clubs, double round-robin, 30 matchdays. Table: points, goal difference, goals scored, name.
- Transfer windows: matchdays 1-4 (summer) and 16-18 (winter). Free agents can be signed any time.
- At season end: players age; under-22s grow toward potential, 30+ decline; retirements at 34+
  (probabilistic) and always at 37; AI contracts auto-renew; your expiring contracts leave
  as free agents; AI squads are refilled with academy youth; your squad is topped up to 18 if it falls lower.

## Match engine (`match_engine.dart`)
Per minute: possession is decided by midfield strength (home +4%), then a chance may occur with
probability `0.205 * tempo * clamp((attack/defence)^1.8, 0.45, 2.2)`. A shooter is chosen by position
and quality, then on-target and goal probabilities depend on shooter vs goalkeeper and attack vs defence.
Yellow cards ~1.7 per team per match (more with high pressing), rare reds and injuries.
Calibrated with a prototype so two equal sides average about 2.5 goals; a side 10 rating points
stronger in every line wins roughly three quarters of matches. Re-check after changing constants
(`test/engine_test.dart` asserts broad bounds).

Determinism: each match uses `mixSeed(mixSeed(careerSeed, season), matchday*100 + fixtureIndex)`.
The seed is stored in `MatchResult`, so any match can be replayed.

## Economy (`economy.dart`)
- Value ~ `40,000 * e^(0.19*(rating-50))`, boosted for high-potential youngsters, reduced after 29.
- Weekly wage ~ `1,500 * e^(0.09*(rating-50))`.
- Asking price = value x (1.10 + premiums for star players and thin positions - 0.15 if contract ending).
  Bid >= ask accepted; >= 85% countered at ask; lower rejected. Clubs refuse to sell below 18 players.
- Income per matchday: TV (reputation x 1,400) plus gate for home games; costs are wages plus 60,000 running costs.
