# Real-world football data and licensing

The game is intended to support real-world football. The first prototype uses fictional
demo records so development can proceed without redistributing protected datasets.

Before importing real data, choose a provider whose contract permits:
- use inside a commercial mobile game
- offline caching and persistence
- display of player names, statistics and club information
- territory and platform distribution
- attribution requirements
- retention after subscription or contract termination

Keep provider-specific identifiers and source metadata. Do not assume that a public API,
website, open-source package or publicly visible page grants commercial redistribution rights.

Official crests, league logos, kits, player photographs, and some player identity/likeness
rights may require separate permissions. Use original placeholder graphics until cleared.

Suggested provider adapter contract:
- `getCompetitions()`
- `getSeasons(competitionId)`
- `getTeams(competitionId, seasonId)`
- `getSquad(teamId, seasonId)`
- `getFixtures(competitionId, seasonId)`
- `getFixtureEvents(fixtureId)`

The adapter maps provider records into Football Dynasty's own internal schema.
