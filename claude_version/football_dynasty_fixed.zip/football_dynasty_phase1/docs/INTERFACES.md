# Interface specifications

## Visual system
- Deep navy background `#0B1420`
- Panel `#152334`
- Elevated panel `#203348`
- Electric green accent `#9BE15D`
- Gold highlight `#FFC857`
- Rounded cards, strong contrast, compact mobile-first layouts

## Primary navigation
1. Home: club summary, next fixture, finances, inbox highlights
2. Squad: player list, position filters, fitness, morale, contracts
3. Transfers: search, shortlist, bids, loans, contracts
4. League: competitions, tables, fixtures, results
5. Tactics: formation, player roles, mentality, pressing, line, tempo

## Secondary screens
- New career and manager profile
- Club selection
- Match centre
- Player profile
- Scouting report
- Training
- Finances
- Staff
- Stadium and facilities
- Settings and save management

## UX rules
- All core career actions must be available offline.
- Clearly label stale online data and last synchronization time.
- Never display a fake live score or pretend a fixture is real.
- Demo records must be visibly labelled until licensed data is connected.
- Confirm irreversible actions such as releasing or selling a player.
- Support smaller Android screens and low-memory devices.
