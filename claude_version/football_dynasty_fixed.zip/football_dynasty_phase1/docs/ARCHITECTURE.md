# Architecture

## Offline-first data flow
- Flutter screens read from local repositories.
- Local SQLite is the gameplay source of truth on the device.
- Mutations are committed locally first.
- A sync queue records eligible changes for later upload.
- Supabase is optional for authentication, backup and cross-device sync.
- Provider imports are handled by a separate football-data adapter and never called directly by widgets.

## Planned modules
- `core`: configuration, errors, logging, utilities
- `domain`: entities, value objects, use cases
- `data/local`: SQLite database, migrations, DAOs
- `data/remote`: Supabase API, provider clients
- `data/sync`: outbox, conflict resolution, sync worker
- `features/career`: manager and save slots
- `features/club`: squad, facilities and finances
- `features/transfers`: scouting and negotiations
- `features/competitions`: seasons, fixtures and tables
- `features/tactics`: formations and instructions
- `features/match`: simulation rules and match events
- `presentation`: Flutter screens and widgets
- `match_view`: Flame rendering of simulation events

## Match engine boundary
The match engine produces a time-ordered list of domain events. Flame consumes those
events to animate the pitch. Rendering must not decide match outcomes. The simulation
should accept a stored random seed so a match can be replayed for debugging.

## Sync rules
- Local career actions must work offline.
- Sync only records that are safe and meaningful to synchronize.
- Use stable UUIDs for local records.
- Provider source IDs are stored separately from internal IDs.
- Conflict policies must be explicit per table; do not blindly overwrite career progress.

## Implementation status (current)
- `domain/` is pure Dart and holds all rules; `Career` is the single serialisable aggregate.
- `data/save_store.dart` implements the local source of truth as JSON files (not SQLite).
  The `SaveStore` interface allows swapping in SQLite later without touching domain code.
  SQLite becomes worthwhile when saves hold many seasons of history or need partial loading.
- `state/game_controller.dart` is the only place screens mutate state; it saves after every action.
- The sync queue, Supabase client and conflict resolution described above are **not built**.
  A reasonable first step is to upload whole-save snapshots with a version counter
  (last-write-wins per slot, with a conflict prompt), then move to per-table sync if needed.
- Flame is not used yet. A match view should consume `MatchResult.events`; it must not decide outcomes.
